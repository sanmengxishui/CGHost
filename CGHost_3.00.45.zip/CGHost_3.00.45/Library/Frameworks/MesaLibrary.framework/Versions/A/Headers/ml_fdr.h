//
//  ml_fdr.h
//
//  Created by Joon Kwon on 9/12/11.
//  moved to MesaLibrary by Joon Kwon on 10/2/14.
//  Copyright (c) 2011 APPLE. All rights reserved.
//

#ifndef _ML_FDR_H_
#define _ML_FDR_H_

#include "ml_log.h"

/*------------------------------------------------------------------------------
 *	FDR Settings
 */
typedef enum {
	k_mlFdrActionGET,
	k_mlFdrActionPUT,
	k_mlFdrActionDELETE,
} t_mlFdrAction;

struct t_mlFdrCertReq {
	uint32_t		fdrTag;
	t_mlFdrAction	fdrAction;
};

struct t_mlFdrConfig {
	const char* caUrl;
	const char* dsUrl;
	const char* trustObjectUrl;
	const char* dryRunUrl;
	CFMutableStringRef permission;
	t_mlFdrConfig(){memset(this, 0, sizeof(t_mlFdrConfig));}
};

/*------------------------------------------------------------------------------
 *	FDR Tags
 */
#define kFDR_TAG_FSCL	'FSCl'
#define kFDR_TAG_HOP0	'hop0'
#define kFDR_TAG_NVMR	'NvMR'
#define kFDR_TAG_ATED	'ateD'
#define kFDR_TAG_MRLD	'mRLD'
#define kFDR_TAG_SIHL	'SihL'
#define kFDR_TAG_IFCL	'IfCl'
#define kFDR_TAG_CTCL	'CtCl'
#define kFDR_TAG_HMCL	'HmCl'
#define kFDR_TAG_IFRL	'IfRl'

#define kFDR_TAG_HOP_DATA	kFDR_TAG_HOP0
#define kFDR_TAG_CAL_TABLE	kFDR_TAG_FSCL
#define kFDR_TAG_MR_DATA	kFDR_TAG_NVMR
#define kFDR_TAG_ATE_DATA	kFDR_TAG_ATED
#define kFDR_TAG_REL_DATA	kFDR_TAG_MRLD

static const inline char* mlFdr_getTagString(uint32_t fdrTag){
	switch(fdrTag){
		case kFDR_TAG_HOP_DATA			:	return "hop0";
		case kFDR_TAG_CAL_TABLE			:	return "FSCl";
		case kFDR_TAG_MR_DATA			:	return "NvMR";
		case kFDR_TAG_ATE_DATA			:	return "ateD";
		case kFDR_TAG_REL_DATA			:	return "mRLD";
		case kFDR_TAG_SIHL				:	return "SihL";
		case kFDR_TAG_IFCL				:	return "IfCl";
		case kFDR_TAG_CTCL				:	return "CtCl";
		case kFDR_TAG_HMCL				:	return "HmCl";
		case kFDR_TAG_IFRL				:	return "IfRl";

		default							:	return "";
	}
};

#if defined(__cplusplus)
class CML_fdr: public CML_baseObject{
protected:
	std::string			_fdrDryRunUrl;
	std::string			_fdrCaUrl;
	std::string			_fdrDsSetUrl;
	std::string			_fdrDsGetUrl;
	std::string			_fdrTrObjUrl;
public:
	CML_fdr();
	virtual ~CML_fdr();
	t_mlError setLogManager(CML_logManager* lm);
public:
	void setFdrDryRunUrl(std::string fdrDryRunUrl){_fdrDryRunUrl = fdrDryRunUrl;};
	void setFdrCaUrl(std::string fdrCaUrl){_fdrCaUrl = fdrCaUrl;}
	void setFdrDsSetUrl(std::string fdrDsSetUrl){_fdrDsSetUrl = fdrDsSetUrl;}
	void setFdrDsGetUrl(std::string fdrDsGetUrl){_fdrDsGetUrl = fdrDsGetUrl;}
	void setFdrTrObjUrl(std::string fdrTrObjUrl){_fdrTrObjUrl = fdrTrObjUrl;}
	
	t_mlError setPermission();
public:
	t_mlError setData(const uint8_t* pData, const int dataSize, bool doAsync = false);
	t_mlError getData(uint8_t* ppData, int* pDataSize, bool doAsync = false);
};
#endif

/*------------------------------------------------------------------------------
 *	FDR Helper Functions
 */
#ifdef __cplusplus
extern "C" {
#endif
#	if TARGET_OS_IPHONE
	t_mlError mlFdr_get_data(CML_logManager* lm,
							 const uint32_t fdrTag,
							 const char*	module_sn,
							 uint8_t**		ppDataBuff,
							 int*			pDataBuffLen,
							 t_mlVbsLvl vbsLvl);
	//			description
	//				Retrieve FDR Data from Form Factor storage, No server connection required
	//			parameter:
	//				[Input]
	//				lm:				log manager
	//				fdrTag:			FDR Tag. Tags available for Mesa are following:
	//								. 'FSCl' -> Calibration Table
	//								. 'hop0' -> Hops Table
	//								. 'NvMR' -> Modulation Ratio Data
	//								. 'ateD' -> ATE Channel Calibration Data, not available for Navajo Sensor
	//				module_sn:		Mesa module serial number
	//				[Output]
	//				ppDataBuff:		Pointer to the bitstream of FDR data. Warning! Must be freed afterwards!
	//				pDataBuffLen:	Pointer to the length of FDR data.
	//				[Misc.]
	//				vbsLvl:			log verbose level
	//			return
	//				t_mlError:		MesaLibrary error code
	
#	else// TARGET_OS_IPHONE
	t_mlError mlFdr_set_data(CML_logManager* lm,
							 const uint32_t fdrTag,
							 const char* module_sn,
							 const char* ca_url,
							 const char* ds_url,
							 const char* trObj_url,
							 const uint8_t* dataBuff,
							 const int dataBuffLen,
							 t_mlStationId stationId,
							 const char* logFilePath,
							 t_mlVbsLvl vbsLvl)__attribute__((deprecated("use mlFdr_setData instead")));
	//			description
	//				Upload FDR Data to FDR server. Require server connection!
	//			parameter:
	//				[Input]
	//				lm:				log manager
	//				fdrTag:			FDR Tag. Tags available for Mesa are following:
	//								. 'FSCl' -> Calibration Table
	//								. 'hop0' -> Hops Table
	//								. 'NvMR' -> Modulation Ratio Data
	//								. 'ateD' -> ATE Channel Calibration Data, not available for Navajo Sensor
	//				module_sn:		Mesa module serial number
	//				ca_url:			FDR Server CA Server URL
	//				ds_url:			FDR Server DS Server URL
	//				trObj_url:		FDR Server Server Trust Object URL
	//				dataBuff:		Bitstream of FDR data.
	//				dataBuffLen:	Length of FDR data.
	//				stationId:		Mesa Station ID for getting corresponding permissions
	//								. k_mlStation_module will request PUT and GET Permissions from FDR Server
	//								. All other stationId will only request GET Permission from FDR Server
	//				[Misc.]
	//				logFilePath:	[optional] specify the path for storing FDR Server log file
	//				vbsLvl:			log verbose level
	//			return
	//				t_mlError:		MesaLibrary error code
	
	t_mlError mlFdr_get_data(CML_logManager*	lm,
							 const uint32_t		fdrTag,
							 const char*		module_sn,
							 const char*		ca_url,
							 const char*		ds_url,
							 const char*		trObj_url,
							 t_mlStationId		stationId,
							 uint8_t**			ppDataBuff,
							 int*				pDataBuffLen,
							 const char*		logFilePath,
							 t_mlVbsLvl vbsLvl)__attribute__((deprecated("use mlFdr_getData instead")));
	//			description
	//				Retrieve FDR Data to FDR server. Require server connection!
	//			parameter:
	//				[Input]
	//				lm:				log manager
	//				fdrTag:			FDR Tag. Tags available for Mesa are following:
	//								. 'FSCl' -> Calibration Table
	//								. 'hop0' -> Hops Table
	//								. 'NvMR' -> Modulation Ratio Data
	//								. 'ateD' -> ATE Channel Calibration Data, not available for Navajo Sensor
	//				module_sn:		Mesa module serial number
	//				ca_url:			FDR Server CA Server URL
	//				ds_url:			FDR Server DS Server URL
	//				trObj_url:		FDR Server Server Trust Object URL
	//				stationId:		Mesa Station ID for getting corresponding permissions
	//								. k_mlStation_module will request PUT and GET Permissions from FDR Server
	//								. All other stationId will only request GET Permission from FDR Server
	//				[Output]
	//				ppDataBuff:		Pointer to the bitstream of FDR data. Warning! Must be freed afterwards!
	//				pDataBuffLen:	Pointer to the length of FDR data.
	//				[Misc.]
	//				logFilePath:	[optional] specify the path for storing FDR Server log file
	//				vbsLvl:			log verbose level
	//			return
	//				t_mlError:		MesaLibrary error code
	
	t_mlError mlFdr_get_data_mem(CML_logManager*	lm,
								 const uint32_t		fdrTag,
								 const char*		module_sn,
								 const char*		plist_path,
								 uint8_t**			ppDataBuff,
								 int*				pDataBuffLen,
								 const char*		logFilePath,
								 t_mlVbsLvl vbsLvl);
	//			description
	//				Retrieve FDR Data from system partition and decode.
	//			parameter:
	//				[Input]
	//				lm:				log manager
	//				fdrTag:			FDR Tag. Tags available for Mesa are following:
	//								. 'FSCl' -> Calibration Table
	//								. 'hop0' -> Hops Table
	//								. 'NvMR' -> Modulation Ratio Data
	//								. 'ateD' -> ATE Channel Calibration Data, not available for Navajo Sensor
	//				module_sn:		Mesa module serial number
	//				plist_path:		Path to plist FDR Data format
	//				[Output]
	//				ppDataBuff:		Pointer to the bitstream of FDR data. Warning! Must be freed afterwards!
	//				pDataBuffLen:	Pointer to the length of FDR data.
	//				[Misc.]
	//				logFilePath:	[optional] specify the path for storing FDR Server log file
	//				vbsLvl:			log verbose level
	//			return
	//				t_mlError:		MesaLibrary error code
	
	t_mlError mlFdr_del_data(CML_logManager* lm,
							 const uint32_t fdrTag,
							 const char* module_sn,
							 const char* ca_url,
							 const char* ds_url,
							 const char* trObj_url,
							 t_mlStationId stationId,
							 const char* logFilePath,
							 t_mlVbsLvl vbsLvl);
	//			description
	//				Delete FDR Data to FDR server. Require server connection!
	//				DEBUGGING PURPOSE ONLY !!!
	//			parameter:
	//				[Input]
	//				lm:				log manager
	//				fdrTag:			FDR Tag. Tags available for Mesa are following:
	//								. 'FSCl' -> Calibration Table
	//								. 'hop0' -> Hops Table
	//								. 'NvMR' -> Modulation Ratio Data
	//								. 'ateD' -> ATE Channel Calibration Data, not available for Navajo Sensor
	//				module_sn:		Mesa module serial number
	//				ca_url:			FDR Server CA Server URL
	//				ds_url:			FDR Server DS Server URL
	//				trObj_url:		FDR Server Server Trust Object URL
	//				stationId:		Mesa Station ID for getting corresponding permissions
	//								. k_mlStation_module will request PUT and GET Permissions from FDR Server
	//								. All other stationId will only request GET Permission from FDR Server
	//				[Misc.]
	//				logFilePath:	[optional] specify the path for storing FDR Server log file
	//				vbsLvl:			log verbose level
	//			return
	//				t_mlError:		MesaLibrary error code
	
#	endif//TARGET_OS_IPHONE
	
	t_mlError mlFdr_setFdrLogLevel(uint8_t logLevel);
	//			description:
	//				set FDR Log level
	//			parameter:
	//				logLevel:
	//					0 = LOG_EMERG
	//					1 = LOG_ALERT
	//					2 = LOG_CRIT
	//					3 = LOG_ERR
	//					4 = LOG_WARNING
	//					5 = LOG_NOTICE
	//					6 = LOG_INFO
	//					7 = LOG_DEBUG
	//			return
	//				t_mlError:		MesaLibrary error code
	
	CFMutableStringRef mlFdr_createFdrPermission(CML_logManager*		lm,
											  const t_mlFdrCertReq*	fdrCertReqs,
											  const int				fdrCertReqCnt,
											  const char*			fdrLogFilePath,
											  t_mlVbsLvl vbsLvl);
	
	t_mlError mlFdr_setData(CML_logManager*			lm,
							const uint32_t			fdrTag,
							const char*				fdrKey,
							const t_mlFdrConfig		fdrConfigs,
							const uint8_t*			fdrDataBuff,
							const int				fdrDataBuffLen,
							const t_mlFdrCertReq*	fdrCertReqs,
							const int				fdrCertReqCnt,
							const char*				fdrLogFilePath,
							t_mlVbsLvl vbsLvl);
	//			description
	//				Set FDR Data
	//			parameter:
	//				[Input]
	//				lm:				log manager
	//				fdrTag:			FDR Tag
	//				fdrKey:			module serial number or other eSN
	//				fdrConfig:		configs for FDR operation
	//								. caUrl -> FDR Server CA Server URL
	//								. dsUrl -> FDR Server DS Server URL
	//								. trustObjectUrl -> FDR Server Server Trust Object URL
	//								. dryRunUrl -> When not NULL, data save to local path
	//				fdrDataBuff:	Bitstream of FDR data.
	//				fdrDataBuffLen:	Length of FDR data.
	//				fdrCertReqs:	[Optional] array of fdr permission/certificate request
	//								. For FDR operation require Network connection.
	//								. Permission need to be requested for each fdrTag
	//								. e.g.
	//								.	{'NvMR', k_mlFdrActionGET} for GET permission for NvMR
	//								.	{'FSCl', k_mlFdrActionSET} for SET permission for FSCl
	//				fdrCertReqCnt:	number of fdr permission requests
	//				[Misc.]
	//				fdrLogFilePath:	[optional] specify the path for storing FDR Server log file
	//				vbsLvl:			log verbose level
	//			return
	//				t_mlError:		MesaLibrary error code
	

	t_mlError mlFdr_getData(CML_logManager*			lm,
							const uint32_t			fdrTag,
							const char*				fdrKey,
							const t_mlFdrConfig		fdrConfigs,
							uint8_t**				ppFdrDataBuff,
							int*					pFdrDataBuffLen,
							const t_mlFdrCertReq*	fdrCertReqs,
							const int				fdrCertReqCnt,
							const char*				fdrLogFilePath,
							t_mlVbsLvl vbsLvl);
	//			description
	//				Get FDR Data
	//			parameter:
	//				[Input]
	//				lm:				log manager
	//				fdrTag:			FDR Tag
	//				fdrKey:			module serial number or other eSN
	//				fdrConfig:		configs for FDR operation
	//								. caUrl -> FDR Server CA Server URL
	//								. dsUrl -> FDR Server DS Server URL
	//								. trustObjectUrl -> FDR Server Server Trust Object URL
	//								. dryRunUrl -> When not NULL, data get from local path
	//				ppFdrDataBuff:		Pointer to the bitstream of FDR data. Warning! Must be freed afterwards!
	//				pFdrDataBuffLen:	Pointer to the length of FDR data.
	//				fdrCertReqs:		[Optional] array of fdr permission/Certificate request
	//									. For FDR operation require Network connection.
	//									. Permission need to be requested for each fdrTag
	//									. e.g.
	//									.	{'NvMR', k_mlFdrActionGET} for GET permission for NvMR
	//									.	{'FSCl', k_mlFdrActionSET} for SET permission for FSCl
	//				fdrCertReqCnt:	number of fdr permission requests
	//				[Misc.]
	//				fdrLogFilePath:	[optional] specify the path for storing FDR Server log file
	//				vbsLvl:			log verbose level
	//			return
	//				t_mlError:		MesaLibrary error code
	
#ifdef __cplusplus
}
#endif
#endif//ifndef _ML_FDR_H_
