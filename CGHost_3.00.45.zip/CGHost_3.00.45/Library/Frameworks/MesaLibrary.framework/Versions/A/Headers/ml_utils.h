//
//  tools.h
//
//  Created by Joon Kwon on 8/27/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_UTILS_H_
#define _ML_UTILS_H_
#include <ml_typedef.h>
#include <ml_error.h>
#include <ml_log.h>
#include <ml_string.h>
#include <ml_file.h>

#if defined(__cplusplus)
extern "C" {
#endif
	
	/*	 system endianess	------------------------------------------------------------------------
	 */
#	pragma mark -
#	pragma mark system endianess
	static inline int mlUtil_GetSystemEndianess(){
		uint8_t tmp[2] = {0x01, 0x02};
		uint16_t* pTmp = (uint16_t*)tmp;
		return (*pTmp==0x0102)?BIG_ENDIAN:LITTLE_ENDIAN;
	}
#	define SWAP_UINT32(x) (\
						(((x)&0xFF000000)>>24)\
						|(((x)&0x00FF0000)>>8)\
						|(((x)&0x0000FF00)<<8)\
						|(((x)&0x000000FF)<<24))
#	define SWAP_UINT16(x) (\
						(((x)&0xFF00)>>8)\
						|(((x)&0x00FF)<<8))

	static inline void mlUtil_getName(uint32_t name, char* strBuff){
		// convert uint32_t magic to string (swap & string conv)
		// use at your own risk
		assert(strBuff!=NULL);
		*(uint32_t*)strBuff = SWAP_UINT32(name);
		strBuff[4]=0;
	}
	
	static inline void mlUtil_getMagic(char* strBuff, uint32_t* name){
		// convert string to magic (swap & bit or)
		assert(strBuff);
		assert(name);
		*name = strBuff[0] << 24 | strBuff[1] << 16 | strBuff[2] << 8 | strBuff[3];
	}
	
	/*	 bundle info	----------------------------------------------------------------------------
	 */
#	pragma mark -
#	pragma mark Bundle Info
	const char* mlUtil_GetBundleName(void);
	const char* mlUtil_GetBundlePath(void);
	const char*	mlUtil_GetAppPath(void);
	const char* mlUtil_GetAppResPath(void);

	/*	 systme info	----------------------------------------------------------------------------
	 */
#	pragma mark -
#	pragma mark system info
	
	void    mlUtil_formatTimestampStr(double timestamp, char* strBuff, int buffLeng, int type);
	double	mlUtil_getTimestampStr(char* strBuff, int buffLeng, int type);
	// type=0	YYYY-MM-dd HH:mm:ss
	// type=1	YYYYMMddHHmmss
	// type=2   %Y%m%d%H%M%S
	t_mlError mlUtil_getCalendar(uint16_t* year, uint8_t* month, uint8_t* dayOfMonth);
	t_mlError mlUtil_getTime(uint8_t* hour, uint8_t* minute, uint8_t* second);
	double	mlUtil_getFromTimestampStr(char* str, int strLen, int strType,
									   uint16_t* year, uint8_t* month, uint8_t* dayOfMonth,
									   uint8_t* hour, uint8_t* minute, uint8_t* second);
	// type=0	YYYY-MM-dd HH:mm:ss
	// type=1	YYYYMMddHHmmss
	// type=2   %Y%m%d%H%M%S
	
#if TARGET_OS_IPHONE
	tDeprecated_SystemInfo* DEPRECAED_GetSystemInfo();
	// syscfg
	t_mlError				mlUtil_sysSysCfgRead(uint32_t key, uint8_t* pBuff, int* pBuffLeng);
	t_mlError				mlUtil_sysSysCfgWrite(uint32_t key, uint8_t* pBuff, int buffLeng);
	t_mlError				mlUtil_sysSysCfgDelete(uint32_t key);
	// sysinfo
	const t_mlSystemInfo*	mlUtil_sysGetSysInfo();
	// sensors
	void					mlUtil_sysListSensors();
	void					mlUtil_sysReadSensors(const char* snsrType, const char* snsrName, float* snsrValue);
	//	snsrType = "currnet" OSDSensorCurrent
	//	snsrType = "voltage" OSDSensorVoltage
	//	snsrType = "Temperature" OSDSensorTemperature
	//
	void					mlUtil_sysCbSet(uint8_t stationId, uint8_t stat, const char* swVersion);
	t_mlCbInfo				mlUtil_sysGetCbInfo(uint8_t stationId);
	void					mlUtil_sysSetBootArg(const char* removeArg, const char* addArg);
	void					mlUtil_sysPowerControl(int option); //1: halt, 2:reboot
#endif//TARGET_OS_IPHONE

	/*	 aligned/multi-dimension memory allocation	------------------------------------------------
	 */
#pragma mark -
#pragma mark aligned/multi-dimension memory allocation
	void*	mlUtil_alignedMemory_alloc(t_mlDataType type, UInt16 dimension, UInt16* dSize, int *rtnMemSize);
	void	mlUtil_alignedMemory_free(void* ptr);
	
	/*	process	------------------------------------------------------------------------------------
	 */
#pragma mark -
#pragma mark process
	pid_t		mlUtil_launchProcess(const char* command, const char* fOut);
	//			description:
	//				launch process and returns the process id
	//			parameter:
	//				command		- null terminated command string to launch a process
	//				fOut		- [optional, can be NULL] filename to be set to the stdout of the process
	//								if it is set to NULL, current stdout will be set
	//			return
	//				pid_t		- the process ID of the process
	t_mlError	mlUtil_performProcess(const char* command, const char* fOut, int* pExitCode);
	//			description:
	//				launch process, wait for the completion of the process and return the exit code
	//			parameter:
	//				command		- null terminated command string to launch a process
	//				fOut		- [optional, can be NULL] filename to be set to the stdout of the process
	//								if it is set to NULL, current stdout will be set
	//				fExitCode	- [optional, can be NULL] the process exit/return code
	//			return
	//				t_mlError	- mesa library error
	t_mlError	mlUtil_killProcess(pid_t pid);
	//			parameter:
	//				pid			- the process id to be killed
	//			return
	//				t_mlError	- mesa library error
	
	/*	 checksum, crc, hash	--------------------------------------------------------------------
	 */
#	pragma mark -
#	pragma mark checksum, crc, hash
	uint32_t	mlUtil_hashFnv32(const uint8_t* data, int length);
	uint16_t	mlUtil_crc16(const uint8_t* data, size_t length);
	uint16_t	mlUtil_crc16_rev(const uint8_t* data, size_t length);
	uint32_t	mlUtil_checksum(char* ptr, size_t length);
	
	/*	 miscellaneous	----------------------------------------------------------------------------
	 */
#	pragma mark -
#	pragma mark misc.
	// convert MesaLibrary CSV to PDCA Compatible Plist File
	t_mlError mlUtil_csvToPlist(const char* csvPath, const char* plistPath, bool stopOnFailure, bool doSimple, bool doOnlyLastTest);
	// count one
	static inline int mlUtil_countOne(UInt64 val){int cnt =0;while(val){cnt++;val=val& ~(val^(val-1));}return cnt;}
	// system mac address
	const char* mlUtil_getMacAddress(void);
	// random number generation
#	define mlUtil_generateRandomNumber(bound) (int)(((double)rand())/RAND_MAX*(bound))
#if defined(__cplusplus)
	// binary data printing
	void mlUtil_printBinary(CML_logManager* lm, t_mlVbsLvl vbsLvl, void* data, uint32_t leng);
	// binary data saving
	t_mlError mlUtil_saveBitStream(CML_logManager* lm, const char* fileName, const uint8_t* strmBuff, int leng, t_mlVbsLvl vbsLvl);
	// binary data loading
	t_mlError mlUtil_getBitStream(CML_logManager* lm, const char* fileName, uint8_t** ppData, int* pLeng, t_mlVbsLvl vbsLvl);
	t_mlError mlUtil_loadBitStream(CML_logManager* lm, const char* fileName, uint8_t* strmBuff, int* pLeng, t_mlVbsLvl vbsLvl);
#endif

	/*	debug tools	--------------------------------------------------------------------------------
	 */
#	pragma mark -
#	pragma mark debug tools
	void mlDebug_PrintMarker(const char* fileName, const char* className, const char* functionName, const int lineNumber);
#	if defined(DEBUG)
#		define __MARK__		mlDebug_PrintMarker(__FILE__,__className__,__func__,__LINE__);
#	else
#		define __MARK__		{};
#	endif
	void mlDebug_printError(void* lm, const char* file, const char* className, const char* func, int line, t_mlError err, const char* condition);
#	define PRINT_ERROR(lm,err) \
		mlDebug_printError(lm,__FILE__,__className__,__func__,__LINE__,err,"");
#	define CHECK_CONDITION(lm,cond,errCode) {\
		if (!(cond)){\
			err=errCode;\
			mlDebug_printError(lm,__FILE__,__className__,__func__,__LINE__,err,#cond);\
			break;\
		}}
#	define ASSERT_CONDITION(cond) {\
		if (!(cond)){\
			mlDebug_printError(NULL,__FILE__,__className__,__func__,__LINE__,0xF16C,#cond);\
			assert(0);\
		}}
#	define CHECK_ERROR(lm,err) {\
		if (err!=kMLErr_OK){\
			mlDebug_printError(lm,__FILE__,__className__,__func__,__LINE__,err,"");\
			break;\
		}}
#if defined(__cplusplus)
}
#include <string>
#include <vector>

t_mlError mlSys_enableSystemSleep(bool enableSleep);
double mlSys_processMemUsage();
std::string mlUtil_formatTimestampStr(double timestamp, int type = 0);
std::string	mlUtil_getTimestampStr(int type = 0);
// type=0	YYYY-MM-dd HH:mm:ss
// type=1	YYYYMMddHHmmss

uint16_t mlUtil_crc16(const std::vector<uint8_t> data);
uint16_t mlUtil_crc16_rev(const std::vector<uint8_t> data);

bool mlUtil_isEncrypted(std::string fn);
t_mlError mlUtil_encrypt_file(std::string fn, std::string fn_out="");
std::vector<uint8_t> mlUtil_decrypt_file(std::string fn);

/***************************************************************************************************
 *	CML_fifo
 *	Description:	general purpose fifo 
 */
#	pragma mark -
#	pragma mark CML_fifo
class CML_fifo:public CML_baseObject {
protected:
	pthread_mutex_t		_mtx;
	uint32_t			_elementSize;
	void*				_buff;
	void*				_begin;
	void*				_end;
	void*				_head;
	void*				_tail;
public:
	CML_fifo	(uint32_t elementCount = 256*1024, uint32_t elementSize = 1);
	//		description:
	//			constructor
	//		parameter:
	//			elementCount:	[in]	fifo buffer size (default 256K)
	//			elementSize:	[in]	indicates the data block size to write and read (default 1byte)
	//		[NOTE]
	//			when blkSize greater than 1, the write and read function will check if the data
	//			size for writing and reading is multiple of blkSize. 
	//			IF NOT, ASSERTION FAILURE occur.
	~CML_fifo	();
	t_mlError	setLogManager(CML_logManager* lm);
public:
	void		clear();
	//		description:
	//			clear the buffer
	t_mlError	write(const void* buff, uint32_t* pWriteSz);
	//		description:
	//			write data into the buffer
	//		parameter:
	//			buff:			[in]	data
	//			pWriteSz:		[in]	data size
	//							[out]	data written size 
	//		[NOTE 1]
	//			when blkSize greater than 1, the function will check if the data
	//			size (*pWriteSz) is multiple of blkSize
	//			IF NOT, ASSERTION FAILURE occur.
	//		[NOTE 2]
	//			when the free space in FIFO is less than *pWriteSz, the write action will happen
	//			partially.
	uint32_t	dataSize();		
	//		description:
	//			returns the data size stored in the FIFO (in bytes)
	t_mlError	read(void* buff, uint32_t* pReadSz);
	//		description:
	//			read data fom the buffer
	//		parameter:
	//			buff:			[in]	data
	//			pReadSz:		[in]	read buffer size
	//							[out]	data size that is read
	//		[NOTE]
	//			when blkSize greater than 1, the function will check if the data
	//			size (*pReadSz) is multiple of blkSize
	//			IF NOT, ASSERTION FAILURE occur.
};
#endif//defined(__cplusplus)
#endif//ifndef _ML_UTILS_H_
