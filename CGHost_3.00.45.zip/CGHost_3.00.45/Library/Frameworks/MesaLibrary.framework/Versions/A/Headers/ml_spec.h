//
//  ml_spec.h
//
//  Created by Joon Kwon on 10/6/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_SPEC_H_
#define _ML_SPEC_H_
#include "ml_typedef.h"
#include "ml_log.h"
#include "ml_math.h"

#define SPEC_TABLE_BEGIN enum 
#define DECLARE_SPEC(title,type,lowerLimit,upperLimit) title,
#define SPEC_TABLE_END ;

typedef struct t_mlSpecItem {
	char*	symbol;
	double	lower;
	double	upper;
} t_mlSpecItem, *t_mlSpecItemPtr;

#if defined(__cplusplus)
class CML_specManager: public CML_baseObject {
protected:
	CML_logManager*		_lm;
	t_mlDataItem*		_pSpecTable_org;
	t_mlDataItem*		_pSpecTable_rtm;
	int 				_specItemCount;
	int					_specItemTitleLengthMax;
	//
	double				_timeStamp_begin;
	char				_strTimeStamp_begin[64];
	double				_timeStamp_end;
	char				_strTimeStamp_end[64];
	//
	int					_errorCodeCounts;
	uint16_t*			_pErrorCodes;
	const char**		_pStrErrorStrings;
public:
	CML_specManager();
	~CML_specManager();
	t_mlError			setLogManager(CML_logManager* lm);
	/*
	 *	spec table management
	 */
	t_mlError			setSpecTable(t_mlDataItem* pSpecTable, int specItemCount);
	t_mlError			initializeSpecManager();
	const t_mlDataItem* getDataItem(int dataId);
	t_mlError			importSpecFromCsv(const char* csvFileName);
	t_mlError			exportSpecToCsv(const char* csvFileName);
	//
	t_mlError			overrideSpec(int dataId, double limitLower, double limitUpper);
	double				getLimitLower(int dataId);
	double				getLimitUpper(int dataId);
	/*
	 *	record/get data
	 */
	t_mlError			recordDat(int dataId, double data);
	t_mlError			recordStr(int dataId, const char* strData);
	double				getDat(int dataId);
	const char*			getStr(int dataId);
	/*
	 *	record/get error code
	 */
	t_mlError			recordErr(int errCode, const char* errStr);
	void				resetErrList();
	// retreive error information recorded
	int					getErrCount()	{return (!INSTANCE_VALID)?0:	MAX(_errorCodeCounts,1);};
	const uint16_t*		getErrCodes()	{return (!INSTANCE_VALID)?NULL:	_pErrorCodes;};
	const char**		getErrStrings()	{return (!INSTANCE_VALID)?NULL:	_pStrErrorStrings;};
	/*
	 *	check spec
	 */
	t_mlError			checkspec(int dataId, const char* format);
	/*
	 *	test time handling
	 */
	void				setTestTime_begin();
	void				setTestTime_end();
	//
	double 				testTime_begin()	{return INSTANCE_VALID?_timeStamp_begin	:NA;}
	double 				testTime_end()		{return INSTANCE_VALID?_timeStamp_end	:NA;}
	double 				testTime()			{return INSTANCE_VALID?(_timeStamp_end-_timeStamp_begin):NA;};
	//
	const char* 		testTimeStr_begin()	{return INSTANCE_VALID?(const char*)_strTimeStamp_begin	:"";}
	const char* 		testTimeStr_end()	{return INSTANCE_VALID?(const char*)_strTimeStamp_end	:"";}
	/*
	 *	misc.
	 */
	t_mlError			listSpec();
};

#endif//defined(__cplusplus)
#endif//ifndef _ML_SPEC_H_
