//
//  ml_csv.h
//
//  Created by Joon Kwon on 10/2/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_CSV_H_
#define _ML_CSV_H_
#include "ml_typedef.h"
#include "ml_log.h"

#if defined(__cplusplus)

/*	CML_csvWriter
 *	creates/write csv file
 *	procedure:
 *		. create the instance
 *		. [optional] set maximum data count (default 2048), through setEntryCntMax
 *		. [optional] add attributes
 *		. set serial number
 *		. add data
 *		. call 'write' function for actual file writting.
 *			csv file title and version string should be provided for the intiial file creation
 */
class CML_csvWriter: public CML_baseObject {
protected:
	uint32_t				_entryCntMax;
	const t_mlDataItem**	_pAttrItems;
	uint32_t				_attrCnt;
	const t_mlDataItem**	_pDataItems;
	uint32_t				_dataCnt;
public:
	CML_csvWriter();
	CML_csvWriter(CML_logManager* lm, int entryCountMax = 2048);
	~CML_csvWriter();
	t_mlError	setLogManager(CML_logManager* lm);
	t_mlError	setEntryCntMax(uint32_t entryCntMax);
	//
	void		reset();
	//
	t_mlError	addAttr(const t_mlDataItem* pDataItem);
	int			attrCount(){return INSTANCE_VALID?_attrCnt:0;};
	t_mlError	addData(const t_mlDataItem* pDataItem);
	int			dataCount(){return INSTANCE_VALID?_dataCnt:0;};
	//
	t_mlError	write(const char* const filePathName,
					  const char* strTitle,
					  const char* strVersion,
					  const char* serialNumber,
					  t_mlError testErrCode,
					  const char* testErrCodeStr,
					  const char* strTime_start,
					  const char* strTime_stop,
					  double timestamp,
					  double testTime);
};

#include <vector>
#include <string>
/*	CML_csvParser
 *	parse csv file
 */
class CML_csvParser: public CML_baseObject {
protected:
	std::string			_stationType;
	std::string			_swVersion;
	//
	std::string								_fileBuffer;
	std::vector<std::string>				_titleRow;
	std::vector<std::string>				_lowerLimitRow;
	std::vector<std::string>				_upperLimitRow;
	std::vector<std::vector<std::string> >	_dataRow;
public:
	CML_csvParser();
	CML_csvParser(CML_logManager* lm);
	~CML_csvParser();
	t_mlError	setLogManager(CML_logManager* lm);
public:
	t_mlError		load(const char* csvFilePath, t_mlVbsLvl vbsLvl = kVL2);
	int				getDataCol();
	int				getDataRow();
	int				findColIdx(const char* title);
	double			getData(int dataSetIdx, int dataItemIdx);
	std::string		getStr(int dataSetIdx, int dataItemIdx);
};

/***************************************************************************************************
 *	CML_csv
 *
 */
#pragma mark -
#pragma mark CML_csv

// anchors
typedef enum {
	k_mlCsv_type_normal = 0,
	k_mlCsv_type_test_limit,
	k_mlCsv_type_grr_config,
	//
	k_mlCsv_type_MAX,
	k_mlCsv_type_unknown = -1,
} t_mlCsv_type;

static const char* k_mlCsv_anchors[k_mlCsv_type_MAX] = {
	"SerialNumber",	//	normal test result csv file
	"SpecItem",		//	test limit
	"GrrConfig",	//	grr config
	//
};

// version info prefix
#define k_mlCsv_sw_version_info_prefix		"sw_version:"
#define k_mlCsv_spec_version_info_prefix	"spec_version:"

// header
#define k_mlCsv_header_marker		"->"	// anything that has "->" is regarded as the header
#define k_mlCsv_marker_limit_upper	"Upper Limit"
#define k_mlCsv_marker_limit_lower	"Lower Limit"
#define k_mlCsv_marker_ers_upper	"Upper ERS"
#define k_mlCsv_marker_ers_lower	"Lower ERS"
#define k_mlCsv_marker_unit			"Unit"
#define k_mlCsv_marker_grr_stdev	"GRR Stdev"
#define k_mlCsv_marker_grr_limit	"GRR Limit"

// the list of the pre-defined non-parametric columns
static const char* k_mlCsv_columnToExclude[] = {
	"SerialNumber",
	"StartTime",
	"EndTime",
	"SwVersion",
	"Version",
	"TesterID",
	"Tester ID",
	"StationID",
	"Station ID",
	"Time Stamp",
	"TimeStamp",
};

// column information
struct t_mlCsvColInfo{
	std::string	title;
	bool		isParametric;
	//	data / spec csv
	double		limit_upper;
	double		limit_lower;
	double		ers_upper;
	double		ers_lower;
	//	grr config csv
	double		grr_stdev;
	double		grr_limit;
	//	common
	std::string	str_unit;
	//
	t_mlCsvColInfo():isParametric(false),limit_upper(NA),limit_lower(NA),ers_upper(NA),ers_lower(NA),grr_stdev(NA),grr_limit(NA){};
};

// column statistics
struct t_mlCsvColStat{
	std::vector<double>	data;
	double		max;
	double		min;
	double		avg;
	double		stdev;
	double		cpl, cpu, cpk;
	double		yield;
	t_mlCsvColStat():max(NA),min(NA),avg(NA),stdev(NA),cpl(NA),cpu(NA),cpk(NA),yield(NA){};
};

class CML_csv: public CML_baseObject {
protected:
	t_mlCsv_type							_type;
	std::string								_grp_name;	// group name
	std::vector<t_mlCsvColInfo>				_col_info;
	std::vector<std::vector<std::string>>	_buff_str;
	std::vector<std::vector<double>>		_buff_val;
	std::vector<t_mlCsvColStat>				_col_stat;
	//
	std::string								_title;
	std::string								_sw_version;
	std::string								_spec_version;
	//
	void calculate_col_stat();
public:
	CML_csv():_type(k_mlCsv_type_unknown){ML_SET_CLASS_NAME};
	CML_csv(std::string fn):CML_csv(){load(fn);};
	virtual ~CML_csv(){};
	t_mlError setLogManager(CML_logManager* lm);
public:
	t_mlError			load(std::string fn);
	const std::string&	sw_version()	{	return _sw_version;			};
	const std::string&	spec_version()	{	return _spec_version;		};
	t_mlCsv_type	 	type()			{	return _type;				};
	size_t				rows()			{	return _buff_str.size();	};
	size_t				cols()			{	return _col_info.size();	};
	CML_csv&			merge(const CML_csv& csv);
public:
	uint32_t			timeSort();
public:
	CML_csv&			operator +=	(const CML_csv& csv){return merge(csv);};
	CML_csv				operator +	(const CML_csv& csv){CML_csv rtn = *this; return rtn+=csv;};
public:
	std::vector<CML_csv> getGroups(std::string str_group_col_name);
	const std::string&	grp_name(){	return _grp_name;	};
public:
	const std::vector<t_mlCsvColInfo>&			col_info(){	return _col_info;	};
	const std::vector<std::vector<std::string>>&buff_str(){	return _buff_str;	};
	const std::vector<std::vector<double>>&		buff_val(){	return _buff_val;	};
	const std::vector<t_mlCsvColStat>&			col_stat(){ calculate_col_stat(); return _col_stat;	};
public:
	void				print(FILE* fp = stdout, const char delimiter='\t');
	void				exportCsv(std::string fileName);
};


#endif//defined(__cplusplus)
#endif//ifndef _ML_CSV_H_
