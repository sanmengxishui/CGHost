//
//  ml_typedef.h
//
//  Created by Joon Kwon on 8/27/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_TYPEDEF_H_
#define _ML_TYPEDEF_H_

#if defined(__APPLE__)
#	include <CoreFoundation/CoreFoundation.h>
#	include <CoreGraphics/CoreGraphics.h>
#	include <IOKit/IOKitLib.h>
#if defined(__OBJC__)
#	include <Foundation/Foundation.h>
#endif
#endif

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/stat.h>
#include <math.h>
#include <unistd.h>
//#include <getopt.h>
#include <assert.h>
#include <AssertMacros.h>
#include <dirent.h>
#include <typeinfo>

#define ML_STATIC_ASSERT(constant_expression) \
	static_assert(constant_expression, #constant_expression)

// suppress compiler warnings
#pragma GCC diagnostic ignored "-Wwrite-strings" //suppress "warning: deprecated conversion from string constant to ‘char*’"

/* MesaLibrary Versioning convention
 */
static const unsigned char	_mesaLibrary_verMajor		=	3;	//!< new files, new features, new functions
static const unsigned char	_mesaLibrary_verMinor		=	27;  //!< changes to behaviors, refactoring, other stuff that doesn't change the API in a major fashion
static const unsigned char	_mesaLibrary_verFix			=	0; //!< only bug fixes

/*! @abstract Get the MesaLibrary Framework Version */
const char* const MesaLibrary_GetVersion(void);

/*! @abstract Get the MesaLibrary Version SW was compiled against */
static inline const char* const MesaLibrary_GetCompiledVersion(){
	static char swVer[64]={0,};
	if (!swVer[0])sprintf(swVer,"MesaLibrary-%d.%d.%d",_mesaLibrary_verMajor,_mesaLibrary_verMinor,_mesaLibrary_verFix);
	return swVer;
}

/*	Station IDs
 */
typedef enum {
	k_mlStation_module = 0,
	k_mlStation_iqc,
	k_mlStation_oqc,
	k_mlStation_rel_t0,
	k_mlStation_rel_tX,
	k_mlStation_sys,
	k_mlStation_sys_cal,
	k_mlStation_s_rel_t0,
	k_mlStation_s_rel_tX,
	k_mlStation_s_ned,
	k_mlStation_tactility,
	//
	k_mlStation_MAX,
}t_mlStationId;

static const char* const k_mlStationStr[] = {
	"Module Calibraiton & Test",
	"Module IQC",
	"Module OQC",
	"Module Rel T0",
	"Module Rel TX",
	"System Test",
	"System Cal",
	"System Rel T0",
	"System Rel TX",
	"System Ned",
	"Tactility Only",
	"Unknown Station"
};

static const char* const k_mlStationCsvStr[] = {
	"Module",
	"Module_IQC",
	"Module_OQC",
	"Module_Rel_T0",
	"Module_Rel_TX",
	"System_Test",
	"System_Cal",
	"System_Rel_T0",
	"System_Rel_TX",
	"System_Ned",
	"Tactility",
	"Unknown"
};

/*	type definitions
 */
#define	NA						((float)-1.754941e-39)
#define _IS_VALID_NUMBER_(val)	(!isinf(val) && !isnan(val) && val!=NA)
#define _TMP_DIR_				"/private/tmp/"

typedef enum {
	k_mlDataType_uint8,
	k_mlDataType_sint8,
	k_mlDataType_uint16,
	k_mlDataType_sint16,
	k_mlDataType_uint32,
	k_mlDataType_sint32,
	k_mlDataType_uint64,
	k_mlDataType_sint64,
	k_mlDataType_float,
	k_mlDataType_double,
	k_mlDataType_string,
	//
	k_mlDataType_MAX,
	k_mlDataType_unknown = k_mlDataType_MAX,
} t_mlDataType;

static const size_t k_mlDataSize[] = {
	sizeof(uint8_t),	//k_mlDataType_uint8,
	sizeof(int8_t),		//k_mlDataType_sint8,
	sizeof(uint16_t),	//k_mlDataType_uint16,
	sizeof(int16_t),	//k_mlDataType_sint16,
	sizeof(uint32_t),	//k_mlDataType_uint32,
	sizeof(int32_t),	//k_mlDataType_sint32,
	sizeof(uint64_t),	//k_mlDataType_uint64,
	sizeof(int64_t),	//k_mlDataType_sint64,
	sizeof(float),		//k_mlDataType_float,
	sizeof(double),		//k_mlDataType_double,
	0,	//k_mlDataType_string,
};

#define k_mlDataItemStrLengMax 256
typedef struct t_mlDataItem{
	const char*			title;
	t_mlDataType		dataType;
	double				lowerLimit;
	double				upperLimit;
	double				value;
	char				strValue[k_mlDataItemStrLengMax];
} t_mlDataItem;

/*	system information
 */
#pragma pack(1)
typedef struct t_mlCbInfo{
	uint8_t	stat;
	uint8_t	failCount;
} t_mlCbInfo;
#pragma pack()

/*	control bits status
 *	refer to FactoryTest/ControlBits.h
 */
typedef enum {
	kControlBitsStatusPassed		= 0, // 0x00,
	kControlBitsStatusIncompleteTest= 1, // 0x01,
	kControlBitsStatusFailed        = 2, // 0x10,
	kControlBitsStatusNotTested		= 3, // 0x11
	kControlBitsStatusUnknown       = 4
} t_mlCbStat;

// 
static const char* const k_mlCbStatStr[] = {
	"Passed",		//ControlBitsStatusPassed			= 0, // 0x00,
	"Incomplete",	//ControlBitsStatusIncompleteTest	= 1, // 0x01,
	"Failed",		//ControlBitsStatusFailed			= 2, // 0x10,
	"NotTested",	//ControlBitsStatusNotTested		= 3, // 0x11
	"Unknown",		//ControlBitsStatusUnknown			= 4 
};

typedef struct tDeprecated_SystemInfo{
	char	ModelName[64];
	char	DeviceName[64];
	char	SystemConfiguration[64];
	char	SerialNumber[64];
	char	MLBSerialNumber[64];
	char	MultitouchSerialNumber[64];
	char	DisplaySerialNumber[64];
	char	GaiaVersion[64];
	char	TestSwVersion[64];
	/* [JK, 7/18/12]
	 * adding the control bits information to the system Info
	 * following arrays have CB stat and fail count of
	 * the stationID from 0x00 ~ 0xFF (all possible test stations)
	 */ 
	UInt8	cbTestStatus[256];
	UInt8	cbFailCounts[256];
} tDeprecated_SystemInfo;

/*	system DUT info
 */
#pragma pack(1)
typedef struct t_mlSystemInfo{
	char	modelName[128];
	char	deviceName[128];
	char	systemConfiguration[128];
	char	serialNumber[128];
	char	sn_multitouch[128];
	char	sn_display[128];
	char	sn_mesa[128];
	t_mlCbInfo cbInfo[256];
} t_mlSystemInfo;
#pragma pack()

/*	host ~ iOS/MesaCal packet structure
 *	TO BE OVERRIDDEN BY MTCP
 */
#pragma pack(1)
typedef struct t_mlPacketHdr{
	uint32_t	mark;
	uint32_t	length;
} t_mlPacketHdr;
#pragma pack()

#pragma pack(1)
typedef struct t_mlPacket{
	t_mlPacketHdr	hdr;
	uint8_t			data[];
} t_mlPacket;
#pragma pack()

// type definitions & constants
#pragma mark -
#pragma macro type definitions
typedef uint16_t t_mlError;
static const char* const __className__ = 0;	// dummy class string for non-class namespace

// macros
#pragma mark -
#pragma macros
#if !defined(msleep)
#	define msleep(ms) usleep(1000*(ms))
#endif

#if !defined(FREE_MEM)
#	define FREE_MEM(ptr) {if(ptr) free(ptr); ptr=NULL;}
#endif

#if !defined(CLOSE_FILE)
#	define CLOSE_FILE(fp) {if(fp){fflush(fp); fclose(fp);} fp=NULL;}
#endif

#if defined(__cplusplus)
#if !defined(DELETE_INSTANCE)
#	define DELETE_INSTANCE(obj) {if(obj!=NULL) delete obj; obj=NULL;}
#endif
#if !defined(DELETE_INSTANCES)
#	define DELETE_INSTANCES(obj_array,size) {\
	if (obj_array!=NULL){\
		for(int i=0; i<size; i++) if (obj_array[i]!=NULL) delete obj_array[i];\
		delete[] obj_array; obj_array = NULL;}}
#endif
#endif//defined(__cplusplus)

#if defined(__cplusplus)
#include <string>
static inline const char* ml_getTypeStr(size_t typeHashCode){
	const char* rtn = "unknown";
		 if (typeHashCode==typeid(uint8_t		).hash_code())	rtn = "uint8_t"	;
	else if (typeHashCode==typeid(uint16_t		).hash_code())	rtn = "uint16_t";
	else if (typeHashCode==typeid(uint32_t		).hash_code())	rtn = "uint32_t";
	else if (typeHashCode==typeid(uint64_t		).hash_code())	rtn = "uint64_t";
	else if (typeHashCode==typeid(int8_t		).hash_code())	rtn = "int8_t"	;
	else if (typeHashCode==typeid(int16_t		).hash_code())	rtn = "int16_t"	;
	else if (typeHashCode==typeid(int32_t		).hash_code())	rtn = "int32_t"	;
	else if (typeHashCode==typeid(int64_t		).hash_code())	rtn = "int64_t"	;
	else if (typeHashCode==typeid(float			).hash_code())	rtn = "float"	;
	else if (typeHashCode==typeid(double		).hash_code())	rtn = "double"	;
	else if (typeHashCode==typeid(std::string	).hash_code())	rtn = "string"	;
	return rtn;
}
#define ML_GET_TYPE_STR(type) ml_getTypeStr(typeid(type).hash_code())

// macros
#pragma mark -
#pragma C++ specific macros
#define kMl_classNameLengthMax	128
#define ML_SET_CLASS_NAME {\
/**/const char* cl = typeid(this).name();\
/**/bool isNumSeen = false;\
/**/while(1){\
/**/	if (!isNumSeen) {if (*cl<'0'||'9'<*cl) cl++;	else isNumSeen=true;}\
/**/	else			{if (*cl<'0'||'9'<*cl) break;	else cl++;			}}\
/**/strncpy(__className__,cl,kMl_classNameLengthMax-1);}

/*
 *	CML_baseObject
 *	the base class of all Mesa Library classes
 */
class CML_logManager;	// forward declaration;log manager 
#define __valid_mark__ 'vald'
#define INSTANCE_VALID (this!=NULL && this->_mark_==__valid_mark__)
class CML_baseObject {
protected:
	char __className__[kMl_classNameLengthMax];
	uint32_t _mark_;
	CML_logManager* _lm;
public:
	CML_baseObject():_lm(0),_mark_(__valid_mark__){ML_SET_CLASS_NAME};
	virtual ~CML_baseObject(){if(!INSTANCE_VALID) return; _mark_=0;__className__[0]=0;};
	//
	const char* getClassName(){return __className__;};
	bool isClassOf(const char* className){return INSTANCE_VALID?strncmp(__className__, className, sizeof(__className__))==0:false;};
	virtual t_mlError setLogManager(CML_logManager* lm) = 0;
	CML_logManager* getLogManager(){return INSTANCE_VALID?_lm:NULL;};
	bool isInstanceValid(){return INSTANCE_VALID;};
};
#define ML_DEFAULT_SET_LOG_MGR(cls) \
t_mlError cls::setLogManager(CML_logManager* lm){\
/**/if(!lm->isInstanceValid())\
/**/	return kMLErr_invalidPointer;\
/**/if(!INSTANCE_VALID)\
/**/	return kMLErr_objectNotAvailable;\
/**/if(strcmp(lm->getClassName(),"CML_logManager"))\
/**/	return kMLErr_invalidPointer;\
/**/_lm = lm;\
/**/return kMLErr_OK;\
}

/*
 *	CML_int_logRelay
 *	the base class of all logManager classes
 */
struct IML_logRelay {
	virtual void onLogRelay(const char* strRelay) = 0;
};
#endif//defined(__cplusplus)

#if defined(__OBJC__) && !TARGET_OS_IPHONE
@protocol mlObjc_protocol_viewControllerAppEvent
//
@required
- (void)viewActivated;
- (void)viewDeactivated;
- (void)applicationWillTerminate:(NSNotification *)notification;
//
@optional
- (void) OnMenu_command_up:(id)sender;
- (void) OnMenu_command_down:(id)sender;
- (void) OnMenu_command_bracket_left:(id)sender;
- (void) OnMenu_command_bracket_right:(id)sender;
- (void) OnMenu_command_shift_c:(id)sender;
@end
#endif//defined(__OBJC__) && !TARGET_OS_IPHONE

#endif//ifndef _ML_TYPEDEF_H_
