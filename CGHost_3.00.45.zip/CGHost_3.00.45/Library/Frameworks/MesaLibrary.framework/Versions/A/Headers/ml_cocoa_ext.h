//
//  ml_cocoa_ext.h
//
//  Created by Joon Kwon on 3/2/16
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_COCOA_EXT_H_
#define _ML_COCOA_EXT_H_
#include <ml_typedef.h>
#if defined(__OBJC__)
#import <Cocoa/Cocoa.h>

// https://developer.apple.com/library/mac/qa/qa1490/_index.html
// Add -ObjC in Other Linker Flags for any Application using Static

#pragma mark -
#pragma mark [NSTextView (OML_TextBox)]
typedef enum {
	kScrollType_none = 0,    //!< the text view shouldn't scroll on update
	kScrollType_begin,       //!< the text view should scroll to the beginning on update
	kScrollType_end,         //!< the text view should scroll to the end on update
	kScrollType_max,         //!< ????
} t_scroolType;

@interface NSTextView (OML_TextBox)
- (void) configureTextFormat:(NSString *)fontName fontSize:(CGFloat)fontSize width:(CGFloat)width;
- (void) setHidden:(BOOL)flag;
- (void) reset;
- (void) appendStr:(NSString*) str;
- (void) appendStr:(NSString*) str scrollType:(t_scroolType)scrollType;
@end

#endif
#endif//ifndef _ML_COCOA_EXT_H_
