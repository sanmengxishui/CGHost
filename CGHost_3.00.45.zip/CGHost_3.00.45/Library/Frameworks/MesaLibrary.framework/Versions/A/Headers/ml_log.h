//
//  ml_log.h
//
//  Created by Joon Kwon on 8/27/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_LOG_MANAGER_H_
#define _ML_LOG_MANAGER_H_
#include "ml_typedef.h"

// typedef
typedef enum {
	kVL0 = 0,	// MP mode minimal logging
	kVL1,	// log manager default
	kVL2,
	kVL3,
	kVL4,
	kVL5,
	kVL6,
	kVLMax,
	kVLUnknown = -1,
} t_mlVbsLvl;

#if defined(__cplusplus)
class CML_logManager: public CML_baseObject {
protected:
	t_mlVbsLvl	_vbsLvl;		// logging/displaying level
	t_mlVbsLvl	_vbsLvl_file;	// log file verbose level, should be level 1 or higher
	char*		 		_logFileName;
	FILE*				_logFile;
	pthread_mutex_t		_mtx_str;
	pthread_mutex_t		_mtx_txt;
	char*				_lineBuffer_str;
	char*				_lineBuffer_txt;
	uint32_t			_logRelay_key;
	IML_logRelay* 		_logRelay;
public:
	CML_logManager();
	virtual ~CML_logManager();
	t_mlError			setLogManager(CML_logManager* lm);
	/* 
	 *	verbose level control
	 */
	t_mlError			setVerboseLevel(t_mlVbsLvl vLvl);
	t_mlVbsLvl			getVerboseLevel(void){return (!INSTANCE_VALID)?kVLUnknown:_vbsLvl;};
	t_mlError 			setVerboseLevel_file(t_mlVbsLvl vLvl);
	t_mlVbsLvl			getVerboseLevel_file(void){return (!INSTANCE_VALID)?kVLUnknown:_vbsLvl_file;};
	/*
	 *	log file handling functions
	 */
	t_mlError			setLogFileName(const char* filePathName); // to stop file logging, pass ""
	const char*			getLogFileName(){return _logFileName;};
	/*
	 *	logging
	 */
	void printString(t_mlVbsLvl vLvl, const char* format, ...);
	void printText(t_mlVbsLvl vLvl, const char* format, ...);
	/*
	 * array printing
	 */
	void print_1d(t_mlVbsLvl vLvl, const char		*pData, int length, bool flip, char* numFormat);
	void print_1d(t_mlVbsLvl vLvl, const uint8_t	*pData, int length, bool flip, char* numFormat);
	void print_1d(t_mlVbsLvl vLvl, const int8_t		*pData, int length, bool flip, char* numFormat);
	void print_1d(t_mlVbsLvl vLvl, const uint16_t	*pData, int length, bool flip, char* numFormat);
	void print_1d(t_mlVbsLvl vLvl, const int16_t	*pData, int length, bool flip, char* numFormat);
	void print_1d(t_mlVbsLvl vLvl, const uint32_t	*pData, int length, bool flip, char* numFormat);
	void print_1d(t_mlVbsLvl vLvl, const int32_t	*pData, int length, bool flip, char* numFormat);
	void print_1d(t_mlVbsLvl vLvl, const float		*pData, int length, bool flip, char* numFormat);
	void print_1d(t_mlVbsLvl vLvl, const double		*pData, int length, bool flip, char* numFormat);

	void print_2d(t_mlVbsLvl vLvl, const char		*pData, int stride, int width, int height, bool flip, char* numFormat);
	void print_2d(t_mlVbsLvl vLvl, const uint8_t	*pData, int stride, int width, int height, bool flip, char* numFormat);
	void print_2d(t_mlVbsLvl vLvl, const int8_t		*pData, int stride, int width, int height, bool flip, char* numFormat);
	void print_2d(t_mlVbsLvl vLvl, const uint16_t	*pData, int stride, int width, int height, bool flip, char* numFormat);
	void print_2d(t_mlVbsLvl vLvl, const int16_t	*pData, int stride, int width, int height, bool flip, char* numFormat);
	void print_2d(t_mlVbsLvl vLvl, const uint32_t	*pData, int stride, int width, int height, bool flip, char* numFormat);
	void print_2d(t_mlVbsLvl vLvl, const int32_t	*pData, int stride, int width, int height, bool flip, char* numFormat);
	void print_2d(t_mlVbsLvl vLvl, const float		*pData, int stride, int width, int height, bool flip, char* numFormat);
	void print_2d(t_mlVbsLvl vLvl, const double		*pData, int stride, int width, int height, bool flip, char* numFormat);
	/*
	 *	log relay
	 */
	void setLogRelay(IML_logRelay* logRelay);
};

#endif//defined(__cplusplus)
#endif//ifndef _ML_LOG_MANAGER_H_
