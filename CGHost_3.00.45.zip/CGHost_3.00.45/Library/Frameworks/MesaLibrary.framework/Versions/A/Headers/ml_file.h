//
//  ml_file.h
//
//  Created by Joon Kwon on 8/27/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_FILE_H_
#define _ML_FILE_H_
#include "ml_utils.h"

typedef struct {
	bool	isFile;
	bool	isDirectory;
	char	name[128];
} t_mlDirEntryInfo;

#if defined(__cplusplus)
extern "C" {
#endif
	
#pragma mark -
#pragma mark [FILE TOOLS]
	/*----------------------------------------------------------------------------------------------
	 *	[FILE TOOLS]
	 */
	bool		mlFile_isFileExist(const char* filePathName);
	size_t		mlFile_getFileSize(FILE* fp);
	void		mlFile_delete(const char* filePathName);
	void		mlFile_mkdir(const char* pathName);
	FILE*		mlFile_openFile(const char* pathName, const char* fileName, const char* mode);
	void		mlFile_readFileFrom(FILE* fp, size_t offset, size_t len, uint8_t *out_buffer);
	
	uint8_t*	mlFile_readFile(const char* filePathName, size_t* out_fileSize);
	/*
	 *	returns the pointer to a memory that has the data of a file
	 *	param:
	 *		filePathName	the file path name
	 *		out_fileSize	[optional] if set, the file size will be returned
	 *	return
	 *		NULL:		file error
	 *		otherwise:	the pointer to a buffer, the buffer size to be the same as
	 *		the result of mlFile_getFileSize function
	 *** NOTE ***
	 *	the caller SHOULD FREE the memory
	 */
	
	t_mlError	mlFile_parseIntelHexFile(char* hexBuff, UInt8* binBuff, size_t* binBuffSz);
	
	uint32_t	mlFile_getDirEntryCount(const char* dirPathName);
	/*
	 *	returns number of entries in the direcotry
	 *	param:
	 *		dirPathName		[in]	the dir path name
	 *	return
	 *		0:		error
	 *		otherwise:	the number of entries in the directory
	 */

	t_mlError	mlFile_getDirEntry(const char* dirPathName, t_mlDirEntryInfo* pEntries, uint32_t* pEntryCount);
	/*
	 *	fill the 'entries' buffer with the directory entry info
	 *	param:
	 *		dirPathName		[in]	the dir path name
	 *		pEntries		[out]	the pointer to the buffer of t_mlDirEntryInfo 
	 *		pEntryCount		[in]	the length of the buffer size
	 *						[out]	the number of entry count
	 *	return
	 *		t_mlError
	 */
#if defined(__cplusplus)
}
#include <vector>
#include <string>
#include <fstream>
#pragma mark -
#pragma mark [FILE TOOLS, CPP]
/*--------------------------------------------------------------------------------------------------
 *	[FILE TOOLS, CPP]
 */
void	mlFile_copyfile(std::string srcFile, std::string desFile);
bool	mlFile_isFileExist(std::string fn);
size_t	mlFile_getFileSize(std::string fn);
std::vector<uint8_t>	mlFile_readFile(std::string fn);

#pragma mark -
#pragma mark [DIR TOOLS, CPP]
/*--------------------------------------------------------------------------------------------------
 *	[DIR TOOLS, CPP]
 */
typedef enum {
	kDirEntryType_unknown = 0,
	kDirEntryType_file,
	kDirEntryType_directory,
	//
	kDirEntryType_MAX,
} t_mlDirEntryType;

static const char* kDirEntryTypeStr[] = {
	"unknown",
	" file  ",
	"  dir  ",
};

struct IML_dirEntry{
	t_mlDirEntryType	type;
	std::string			name;
	IML_dirEntry():type(kDirEntryType_unknown){};
	virtual ~IML_dirEntry(){};
};
std::vector<IML_dirEntry> mlDir_getDirEntry(std::string dirPath);

#endif

#endif//ifndef _ML_FILE_H_
