//
//  ml_socket.h
//
//  Created by Joon Kwon on 10/8/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_SOCKET_H_
#define _ML_SOCKET_H_
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string>
#include <thread>
#include <mutex>
#include "ml_typedef.h"
#include "ml_log.h"
#include "ml_error.h"

typedef enum {
	k_mlSocketStatus_notActive = 0,
	k_mlSocketStatus_launching,	// serverSocket specific
	k_mlSocketStatus_launched,	// serverSocket specific
	k_mlSocketStatus_connecting,
	k_mlSocketStatus_connected,
	k_mlSocketStatus_running,
	k_mlSocketStatus_closing,
	k_mlSocketStatus_max,
} t_mlSocketStatus;

#if defined(__cplusplus)
#pragma mark -
#pragma mark CML_socket
/***************************************************************************************************
 *	client socket
 */
struct IML_socketCallback {
	virtual void		onConnect	(uint32_t sktName) = 0;
	virtual t_mlError	onReceive	(uint32_t sktName) = 0;
	virtual void		onClose		(uint32_t sktName) = 0;
};

class CML_socket: public CML_baseObject{
protected:
	int							_socket;
	uint32_t					_sktName;
	std::string					_peerName;
	uint32_t					_sentTotal;
	uint32_t					_recvTotal;
	volatile t_mlSocketStatus	_sktStatus;	// no optimization on socket status
	double						_tsLastActivity;
	std::mutex					_mtxSocket;
	IML_socketCallback*			_callback;
	//
	dispatch_queue_t			_queueSktStatus;
	dispatch_queue_t			_queueCallback;
	dispatch_queue_t			_queueTs;
public:
	CML_socket();
	CML_socket(CML_logManager* lm);
	virtual ~CML_socket();
	t_mlError			setLogManager(CML_logManager* lm);
public:
	void				setSocketName(uint32_t sktName);
	uint32_t			getSocketName(){return _sktName;};
	/*
	 *	connection
	 */
	t_mlError			Connect(const char* address, uint16_t port, IML_socketCallback* callback);
	t_mlError			Append(int skt, IML_socketCallback* callback);
	void				Close();
	bool				isRunning();
	//
	t_mlError			Send(void* pBuff, size_t buffLength);
	t_mlError			Recv(void* pBuff, size_t *pBuffLength, bool doExactRecv = true);
	/*
	 *	status/statistics/misc.
	 */
	const char*			getPeerName();
	uint32_t			getSentTotal()	{return _sentTotal;};
	uint32_t			getRecvTotal()	{return _recvTotal;};
	void				checkAndClose();
private:
	void				proc_onConnect();
	void				proc_onClose();
	std::thread			_thread;
	void				proc_socket();
};

/***************************************************************************************************
 *	server socket
 */
#pragma mark -
#pragma mark CML_serverSocket
struct IML_serverSocketCallback {
	virtual t_mlError	onAccept(uint32_t sktName) = 0;
	//	[!! note !!] return error code ONLY WHEN Accept() call is failing
	virtual void		onCloseServer(uint32_t sktName) = 0;
};

class CML_serverSocket: public CML_baseObject {
protected:
	int					_socket;
	uint32_t			_sktName;
	uint16_t			_port;
	uint32_t			_acceptTotal;
	IML_serverSocketCallback* _callback;
	volatile t_mlSocketStatus	_svrSktStatus;	// no optimization on socket status
	std::mutex			_mtxSvrSocket;
	//
	dispatch_queue_t	_queueSktStatus;
public:
	CML_serverSocket();
	CML_serverSocket(CML_logManager* lm);
	~CML_serverSocket();
	t_mlError			setLogManager(CML_logManager* lm);
	void				setSocketName(uint32_t sktName);
	uint32_t			getSocketName(){return _sktName;};
	/*
	 *	launch/close
	 */
	t_mlError			Launch(uint16_t port, IML_serverSocketCallback* callback);
	void				Close();
	//
	int					Accept();
	/*
	 *	status/statistics/misc.
	 */
	uint16_t			getPortNumber()		{return _port;};
	t_mlSocketStatus	getStatus()			{return _svrSktStatus;};
	uint32_t			getAcceptTotal()	{return _acceptTotal;};
private:
	std::thread			_thread;
	void				proc_server();
};
#endif//defined(__cplusplus)
#endif//ifndef _ML_SOCKET_H_
