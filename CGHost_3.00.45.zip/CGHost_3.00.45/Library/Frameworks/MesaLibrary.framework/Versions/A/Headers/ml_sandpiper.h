//
//  ml_sandpiper.h
//
//  Created by Joon Kwon on 2/26/15.
//  Copyright (c) 2015 APPLE. All rights reserved.
//

#ifndef _ML_SANDPIPER_H_
#define _ML_SANDPIPER_H_

#include "ml_usb.h"
#include "ml_serial.h"
#include "ml_sandpiper_def.h"
#include <pthread.h>
#if TARGET_OS_MAC
#if !TARGET_OS_IPHONE

#if defined(__cplusplus)
/***************************************************************************************************
 *	CML_sandpiper
 *	Description:	sandpiper board
 */
#pragma mark -
#pragma mark CML_sandpiper

/*	IML_sandpiperCallback call back interface
 */
struct IML_sandpiperCallback{
	virtual void onSandpiperDisconnected(uint32_t name, t_mlUsbDevInfo& devInfo) = 0;
	//		description:
	//			called when the sandpiper board is disconnected
	//		parameter:
	//			name:	the 'name' is the uint32_t type value that is specified at 
	//					CML_sandpiper::setCallback function 
	//		return
	//			none
};

/*	CML_sandpiper
 */
class CML_sandpiper: public CML_baseObject, IML_usbDevCallback {
protected:
	CML_usbDev*				_usbDev;
	uint16_t				_fwVersion;
	char					_boardSn[64];
	float					_spi_buffer_size;
	// callback
	IML_sandpiperCallback*	_callbacks[256];
	uint16_t					_callbackCnt;
	pthread_mutex_t			_mtx;
	//
	struct termios*			_pTtyAttr_original;
	uint8_t					_intfNumHID;
	uint8_t					_intfNumCommData;
	int						_commDataFd;
	uint8_t*				_sendBuff;
	uint32_t				_sendBuffSize;
public:
	CML_sandpiper();
	CML_sandpiper(CML_logManager* lm);
	virtual ~CML_sandpiper();
	t_mlError setLogManager(CML_logManager* lm);
protected:
	//IML_usbDevCallback
	void onUsbDevDisconnected(uint32_t name, t_mlUsbDevInfo& devInfo);
	//
	t_mlError allocateResource();
	t_mlError releaseResource();
public:
	t_mlError setCallback(uint32_t name, IML_sandpiperCallback* callback);
	//		description:
	//			set the call back 
	//		parameter:
	//			name:		uint32_t type value that will be used for identifying sandpiper object
	//			callback:	pointer to a class instance that supports IML_sandpiperCallback interface
	//		return
	//			t_mlError value
public:
	static CML_sandpiper* create(CML_usbDev* pUsbDev);
	//		[STATIC HELPER FUNCTION]
	//		description:
	//			create CML_sandpiper object from pUsbDev
	//		parameter:	
	//			valid pointer to CML_usbDev or its decendents
	//		return:
	//			the pointer to the new CML_sandpiper object
public:
#pragma mark Generic
	/*----------------------------------------------------------------------------
	 *	Generic
	 */
	uint16_t	fwVersion();
	//		description:
	//			returns the FW version of the board.
	//		parameter:	
	//			n/a
	//		return:
	//			the FW version of the board.
	//			[b0~7]	minor rev
	//			[b8~15]	major rev
	//			0xFFFF indicates there's error
	char*		boardSn();
	//		description:
	//			return the sandpiper serial number
	//		parameter:
	//			n/a
	//		return:
	//			the serial number of sandpiper board
	//			NULL indicates there's error
#pragma mark SPI
	/*----------------------------------------------------------------------------
	 *	SPI
	 */
	t_mlError	spi_set_speed(float spiSpeed_MHz);
	//		description:
	//			set up SPI interface frequency
	//		parameter:	
	//			spiSpeed_MHz:	SPI frequency in MHz
	//		return:
	//			t_mlError value
	uint16_t	spi_get_buffer_size();
	//		description:
	//			get spi buffer size
	//		parameter:	
	//			n/a
	//		return:
	//			spi buffer size in byte
	uint16_t	spi_sendRecv(const uint8_t* sendBuff, uint32_t sendLeng, uint8_t* recvBuff, uint32_t recvLeng);
	//		description:
	//			send receive SPI signal
	//		parameter:	
	//			n/a
	//		return:
	//			spi buffer size in byte
#pragma mark GPIO 
	/*----------------------------------------------------------------------------
	 *	GPIO
	 */
	t_mlError	gpi_get_status(uint8_t gpioId, uint8_t* pOnOff);
	//		description:
	//			get gpi status
	//		parameter:	
	//			gpioId:	[in] GPIO ID
	//			pOnOff:	[out] 0: low, 1: high, 0xFF: unknown	
	//		return:
	//			t_mlError value
	t_mlError	gpo_set_status(uint8_t gpioId, uint8_t onOff);
	//		description:
	//			set gpo status
	//		parameter:	
	//			gpioId:	[in] GPIO ID
	//			onOff:	[in] 0: low, 1: high
	//		return:
	//			t_mlError value
#pragma mark LDO
	/*----------------------------------------------------------------------------
	 *	LDO
	 */
	t_mlError	ldo_set_voltage(uint8_t ldoId, float voltage);
	//		description:
	//			set ldo output voltage
	//		parameter:	
	//			ldoId:	[in] ldo id
	//			voltage:[in] voltage
	//		return:
	//			t_mlError value
#pragma mark ADC
	/*----------------------------------------------------------------------------
	 *	ADC
	 */
	t_mlError	adc_get_reading(uint8_t adcId, float* pVoltage);
	//		description:
	//			get adc output voltage
	//		parameter:
	//			adcId:		[in]	adc id
	//			pVoltage:	[out]	adc voltage reading
	//		return:
	//			t_mlError value
#pragma mark EEPROM
	/*----------------------------------------------------------------------------
	 *	EEPROM on SPv3 board, M24512-RMN6TP
	 */
	t_mlError	eeprom_set_data(uint16_t startAddr, const uint8_t* dataBuff, uint32_t dataLeng);
	//		description:
	//			Write data to the eeprom chip in SPv3 board
	//		parameter:
	//			startAddr:		[in]	starting address for data writing
	//			dataBuff:		[in]	data buffer
	//			dataLeng:		[in]	data buffer length
	//		return:
	//			t_mlError value
	t_mlError	eeprom_get_data(uint16_t startAddr, uint8_t* dataBuff, uint32_t dataLeng);
	//		description:
	//			Read data from the eeprom chip in SPv3 board
	//		parameter:
	//			startAddr:		[in]		starting address for data reading
	//			dataBuff:		[in/out]	data buffer
	//			dataLeng:		[in]		data length to be read
	//		return:
	//			t_mlError value
#pragma mark I2C
	/*----------------------------------------------------------------------------
	 *	I2C operation for MCU_I2C2 Channel
	 */
	t_mlError	i2c_set_data(uint8_t devAddr, uint32_t startAddr, const uint8_t* dataBuff, uint32_t dataLeng, bool is8bitData = false);
	//		description:
	//			Write data to the I2C channel
	//		parameter:
	//			devAddr:		[in]	device address on I2C channel
	//			startAddr:		[in]	starting address for data writing
	//			dataBuff:		[in]	data buffer
	//			dataLeng:		[in]	data buffer length
	//		return:
	//			t_mlError value
	t_mlError	i2c_get_data(uint8_t devAddr, uint32_t startAddr, uint8_t* dataBuff, uint32_t dataLeng, bool is8bitData = false);
	//		description:
	//			Read data from the I2C channel
	//		parameter:
	//			devAddr:		[in]	device address on I2C channel
	//			startAddr:		[in]		starting address for data reading
	//			dataBuff:		[in/out]	data buffer
	//			dataLeng:		[in]		data length to be read
	//		return:
	//			t_mlError value
#pragma mark Relay Board Control
	/*----------------------------------------------------------------------------
	 *	Relay board control
	 */
	t_mlError	relayBoard_ctrl(uint8_t relayCtrl, bool status);
#pragma mark DMM
	/*----------------------------------------------------------------------------
	 *	DMM
	 */
	t_mlError	dmm_get_reading(uint8_t channel, bool isBigRange, uint8_t sample_x_1000, t_mlSandpiper_dmm_reading* pReading);
	//		description:
	//			read dmm voltage and current of the channel specified
	//		parameter:	
	//			channel:	[in]	the channel to be read
	//			isBigRange:	[in]	indicates the measurement range
	//			sample_x_1000:[in]	the sample count (x1000)
	//			pReading:	[out]	dmm reading
	//		return:
	//			t_mlError value
	t_mlError	dmm_get_fullReading(uint8_t channel, bool isBigRange, uint8_t mode, uint8_t sample_x_1000, t_mlSandpiper_dmm_reading* pReading);
	//		description:
	//			get dmm full reading of the channel specified
	//		parameter:
	//			channel:	[in]	the channel to be read
	//			isBigRange:	[in]	indicates the measurement range
	//			mode:		[in]	dmm running mode
	//			sample_x_1000:[in]	the sample count (x1000)
	//			pReading:	[out]	dmm reading
	//		return:
	//			t_mlError value
	t_mlError	dmm_switch_range(uint8_t channel, uint8_t isBigRange);
	//		description:
	//			switch range for dmm measurement
	//		parameter:
	//			channel:	[in]	the channel to be read
	//			mode:		[in]	dmm running mode
	//		return:
	//			t_mlError value
	t_mlError	dmm_get_calData(t_dmm_cal_data* pCalData);
    //		description:
    //			read sandpiper board calibration data
    //		parameter:
    //			pReading:	[out]	calibration data
    //		return:
    //			t_mlError value
	t_mlError	dmm_set_calData(t_dmm_cal_data* pCalData);
	//		description:
	//			write sandpiper board calibration data
	//		parameter:
	//			pReading:	[out]	calibration data
	//		return:
	//			t_mlError value
	t_mlError	dmm_set_volDac(uint8_t powerRail, uint8_t dac);
	//		description:
	//			set voltage dac for specified power rail
	//		parameter:
	//			powerRail:	[in]	the power rail to set
	//			dac:		[in]	the dac to set
	//		return:
	//			t_mlError value
#pragma mark Get/Set Report
	/*----------------------------------------------------------------------------
	 *	Get/Set Report
	 */
public:
	t_mlError setReport(uint8_t reportId, void* data, uint32_t length);
	//		description:
	//			set report
	//		parameter:	
	//			reportId:	sandpiper reoprt ID	- defined at ml_sandpiper_def.h
	//			data:		data to be set
	//			length:		data length
	//		return:
	//			t_mlError value
	t_mlError getReport(uint8_t reportId, void* data, uint32_t  length);
	//		description:
	//			get report
	//		parameter:	
	//			reportId:	sandpiper reoprt ID	- defined at ml_sandpiper_def.h
	//			data:		data buffer to be filled
	//			length:		data length
	//		return:
	//			t_mlError value
public:
	t_mlError	writeBuffer(uint8_t* sendBuff, uint32_t sendLeng);
	t_mlError	readBuffer(uint8_t* recvBuff, uint32_t* pRecvLeng);
	t_mlError	writeBufferBulk(uint8_t* sendBuff, uint32_t sendLeng);
	t_mlError	readBufferBulk(uint8_t* recvBuff, uint32_t* pRecvLeng, uint32_t timeoutMsec = 1000);
	t_mlError	clearBulkBuffer();
};

#pragma mark -
#pragma mark CML_sandpiperCal

struct IML_sandpiperCalCallback{
	virtual void onSandpiperCalDisconnect(uint32_t name, t_mlUsbDevInfo& devInfo) = 0;
};

class CML_sandpiperCal: public CML_baseObject, IML_SerialCallback {
protected:
	IML_sandpiperCalCallback*	_callback;
	//
	CML_serial*					_serial;
public:
	CML_sandpiperCal();
	CML_sandpiperCal(CML_logManager*);
	virtual ~CML_sandpiperCal();
	t_mlError setLogManager(CML_logManager* lm);
	bool isClassOf(const char* className){return CML_baseObject::isClassOf(className);};
protected:
	//IML_serialCallback
	void onSerialDisconnected(uint32_t name, t_mlUsbDevInfo& devInfo);
public:
	void setCallback(uint32_t name, IML_sandpiperCalCallback* callback);
public:
	t_mlError	Open();
	void		Close();
	t_mlError	readAgilentV(uint8_t powerRail, double* pV);
	t_mlError	readAgilentI(uint8_t powerRail, uint8_t channel, uint8_t range, double* pI);
	t_mlError	readAgilentR(uint8_t channel, double* pR);
	t_mlError	readAgilentIforTest(uint8_t powerRail, uint8_t channel, uint8_t range, double* pI);
	t_mlError	readAgilentRforTest(uint8_t channel, double* pR);
	t_mlError	resetAgilent();
	
public:
	static CML_sandpiperCal* create(CML_usbDev* pUsbDev);
	//		[STATIC HELPER FUNCTION]
	//		description:
	//			create CML_sandpiperCal object from bsdPathName
	//		parameter:
	//			pUsbDev:	[in]	usb device
	//		return:
	//			the pointer to the new CML_sandpiperCal object
	//		note:
	//			baudRate	19200
	//			format		k_mlSerialPortFormat_8N1;
};

#endif//defined(__cplusplus)
#endif//!TARGET_OS_IPHONE
#endif//TARGET_OS_MAC
#endif//ifndef _ML_SANDPIPER_H_
