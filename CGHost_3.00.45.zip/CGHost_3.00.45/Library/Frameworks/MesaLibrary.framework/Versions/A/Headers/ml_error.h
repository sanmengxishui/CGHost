//
//	ml_error.h
//
//  Created by Joon Kwon on 8/27/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_ERROR_H_
#define _ML_ERROR_H_
#include "ml_typedef.h"
#include "ml_utils.h"

#if !defined(ML_ERROR_TABLE_BEGIN)
#	define ML_ERROR_TABLE_BEGIN enum
#endif

#if !defined(ML_ERROR_TABLE_END)
#	define ML_ERROR_TABLE_END ;
#endif

#if !defined(ML_ERROR_DECLARE)
#	define ML_ERROR_DECLARE(err, code, exception_code) err = code,
#endif

/*------------------------------------------------------------------------------
 *	Error Codes
 */
typedef enum {
	kHandling_unknown = -1,
	kHandling_normal,
	kHandling_applePass,
} t_mlErrorHandlingRule;

ML_ERROR_TABLE_BEGIN{// Error Definition							Error Code	handling rule
	ML_ERROR_DECLARE(kMLErr_OK,										0x0000,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_notSupported,							0x0003,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidData,							0x0004,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidParam,							0x0005,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidTestCondition,					0x0006,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidCondition,						0x0007,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidSpiResponse,						0x000A,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_patchDownloadFailed,					0x000B,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidStatus,							0x000C,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidDataSize,						0x000D,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidI2cResponse,						0x000E,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_timeout,								0x000F,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_dataCheckError,							0x0010,		kHandling_normal)
	
	ML_ERROR_DECLARE(kMLErr_specOverridingFailed,					0x0013,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_dutPowerOnFailed,						0x0014,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_dutPowerOffFailed,						0X0015,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_dmmVReadFailed,							0x001A,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_dmmAReadFailed,							0x001B,		kHandling_normal)
	
	ML_ERROR_DECLARE(kMLErr_mtcpCommunicationError,					0x0090,		kHandling_normal)

	ML_ERROR_DECLARE(kMLErr_deviceIdWriteFailed,					0x00D0,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_deviceIdReadFailed,						0x00D1,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_deviceIdCheckFailed,					0x00D2,		kHandling_normal)

	//230 ~ 235 sensor mode change
	ML_ERROR_DECLARE(kMLErr_invalidSensorModeChangeReq,				0x00E6,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidSensorModeForReq,				0x00E7,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_sensorModeChangeFailed,					0x00E8,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidSensorRegSetting,				0x00E9,		kHandling_normal)
	
	ML_ERROR_DECLARE(kMLErr_nvmCheckFailed_failure,					0x00EA,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_nvmCheckFailed_warning,					0x00EB,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_nvmCheckRefreshFailed,					0x00EC,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_nvmReadFailed,							0x00ED,		kHandling_normal)

	ML_ERROR_DECLARE(kMLErr_snReadFromNvmFailed,					0x00A5,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_snWriteToNvmFailed,						0x00A6,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_snWriteToNvmConfirmFailed,				0x00A7,		kHandling_normal)
	
	ML_ERROR_DECLARE(kMLErr_mrReadFromNvmFailed,					0x00AA,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mrWriteToNvmFailed,						0x00AB,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mrWriteToNvmConfirmFailed,				0x00AC,		kHandling_normal)
	
	ML_ERROR_DECLARE(kMLErr_writeToEEPROMFailed,					0x00B1,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_readFromEEPROMFailed,					0x00B2,		kHandling_normal)
	
	ML_ERROR_DECLARE(kMLErr_snErr_invalidLength,					0x00B4, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_snErr_unknownPlantCode,					0x00B5, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_snErr_unknownEEEECode,					0x00B7, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_snErr_invalidYearCode,					0x00B8, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_snErr_invalidWeekCode,					0x00B9, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_snErr_invalidDayCode,					0x00BA, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_snErr_invalidCharacter,					0x00BB, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_snErr_invalidColorCode,					0x00BC, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_snErr_invalidCheckDigit,				0x00BD, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_snErr_invalidRevCode,					0x00BE, 	kHandling_normal)
	
	ML_ERROR_DECLARE(kMLErr_calBlobWriteFailed,						0x00C8,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_calBlobReadFailed,						0x00C9,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_calBlobDevIdCheckFailed,				0x00CA,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_calBlobCrcError,						0x00CC,		kHandling_normal)
	
	ML_ERROR_DECLARE(kMLErr_moduleConfigCheckFailed,				0x00CD,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_moduleSnCheckFailed,					0x00CF,		kHandling_normal)
	
	ML_ERROR_DECLARE(kMLErr_INCOMPLETE_TEST,						0x00FF,		kHandling_normal)
	
	ML_ERROR_DECLARE(kMLErr_writeControlBitFailed,					0x00CB, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_readControlBitFailed,					0x00CC, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_pdcaSessionStartFailed,					0x00DA, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_networkCBFailed,						0x00DB, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_pdcaFatalError,							0x015E, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_pdcaUploadFailed,						0x0160, 	kHandling_normal)
	
	ML_ERROR_DECLARE(kMLErr_fdr_dataCheckFailed,					0x01F7, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdr_SET,								0x01F8, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdr_GET,								0x01F9, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdr_DEL,								0x01FA, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdr_DEL_confirm,						0x01FB, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdr_FSCl_dataCheckFailed,				0x01FC, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdr_NvMR_dataCheckFailed,				0x01FD, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdr_hop0_dataCheckFailed,				0x01FE, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdr_mRLD_dataCheckFailed,				0x01FF, 	kHandling_normal)
	
	ML_ERROR_DECLARE(kMLErr_fdr_connection_timeout,					0x024E, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdr_duplicatedEntry,					0x024F,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdr_no_entry,							0x0250, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdr_internal_issue,						0x025A, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdr_trustObj_issue,						0x025B, 	kHandling_normal)
	
	//	0xE000 ~ 0xE03F	-	Generic Error Codes
	//	parameter check
	ML_ERROR_DECLARE(kMLErr_invalidPointer,							0xE001,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidBufferSize,						0xE002,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidChecksum,						0xE005,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidDataId,							0xE006,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidDeviceIndex,						0xE007,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidDataType,						0xE008,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidFormat,							0xE009,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_memoryAllocationFailed,					0xE00A,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_objectCreationFailed,					0xE00B,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_threadCreationFailed,					0xE00C,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_processCreationFailed,					0xE00D,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_threadAlreadyRunning,					0xE00E,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_previousRequestInProgress,				0xE010,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_noDataAvailable,						0xE012,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_testAborted,							0xE013,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_lapackError,							0xE015,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_OOS,									0xE016,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_objectNotAvailable,						0xE017,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_actionFailed,							0xE019,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_notEnoughFreeSpace,						0xE01A,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_noTestCtrlBrd,							0xE01C,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_noTestFixture,							0xE01D,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidTestScript,						0xE01F,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidValue_NAN,						0xE020,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidValue_INF,						0xE021,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_invalidObject,							0xE022,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_duplicatedSymbol,						0xE023,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_imageCreationException,					0xE024,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_objectException,						0xE025,		kHandling_normal)

	//	0xE040 ~ 0xE04F	-	file
	ML_ERROR_DECLARE(kMLErr_fileNotExist,							0xE040,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_pathNotExist,							0xE041,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fileSizeGetFailed,						0xE042,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fileOpenFailed,							0xE043,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fileWriteFailed,						0xE044,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fileReadFailed,							0xE045,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_pipeOpenFailed,							0xE046,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fcntlFailed,							0xE047,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_dirOpenFailed,							0xE048,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_dirReadFailed,							0xE049,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fileRemoveFailed,						0xE04A,		kHandling_normal)
	//	0xE050 ~ 0xE068 -	ioreg
	ML_ERROR_DECLARE(kMLErr_ioMasterPort,							0xE050,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ioServiceGetMatchingService,			0xE051,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ioServiceOpen,							0xE052,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ioServiceMatching,						0xE053,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ioServiceGetMatchingServices,			0xE054,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ioServiceAddMatchingNotification,		0xE055,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ioServiceAddInterestNotification,		0xE056,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ioCreatePlugInInterfaceForService,		0xE057,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ioRegistryEntryCreateCFProperty,		0xE058,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_queryInterface,							0xE059,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_usbDeviceRequest,						0xE05A,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_FailedToGetData,						0xE05B,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_FailedToSetData,						0xE05C,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ioConnectCallMethod,					0xE05D,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ioNotificationPortCreate,				0xE05E,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ioNotificationPortGetRunLoopSource,		0xE05F,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_cfDataGetTypeID,						0xE060,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_cfRunLoopGetCurrent,					0xE061,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_hidDeviceCreate,						0xE062,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_hidDeviceOpen,							0xE063,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_hidDeviceGetReport,						0xE064,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_hidDeviceSetReport,						0xE065,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_usbInterfaceRequest,					0xE066,		kHandling_normal)

	//	0xE068 ~ 0xE06F -	lockdown service
	ML_ERROR_DECLARE(kMLErr_amCreateDeviceList,						0xE067,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_amDeviceConnect,						0xE068,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_amDevicePair,							0xE069,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_amDeviceStartSession,					0xE06A,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_amDeviceSecureStartService,				0xE06B,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_amDeviceNotificationSubscribe,			0xE06C,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_amDeviceCopyDeviceLocation,				0xE06D,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_amDServiceConnectionGetSocket,			0xE06E,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_secureLockdownCheckinFailed,			0xE06F,		kHandling_normal)
	//	0xE070 ~ 0xE07F -	USB
	ML_ERROR_DECLARE(kMLErr_cannotFindUsbDevice,					0xE070,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_usbRemoveNotifySetupFailed,				0xE071,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_usbGetReportError,						0xE072,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_usbDevicePowerOffFailed,				0xE073,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_usbDevicePowerOnFailed,					0xE074,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_usbSetReportError,						0xE075,		kHandling_normal)
	//	0xE080 ~ 0xE08F -	serial port
	ML_ERROR_DECLARE(kMLErr_serialCannotFindDevice,					0xE080,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_serialOpenError,						0xE081,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_serialCtrlError,						0xE082,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_serialWriteError,						0xE083,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_serialWriteAbnormal,					0xE084,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_serialReadError,						0xE085,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_serialReadAbnormal,						0xE086,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_serialReadTimeout,						0xE087,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_serialCmdFailed,						0xE088,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_serialAlreadyOpen,						0xE089,		kHandling_normal)
	//	0xE090 ~ 0xE09F -	socket
	ML_ERROR_DECLARE(kMLErr_socketOpenError,						0xE090,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketOptionSetError,					0xE091,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketBindError,						0xE092,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketListenError,						0xE093,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketSelectError,						0xE094,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketPollError,						0xE095,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketAcceptError,						0xE096,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketInvalidAddress,					0xE097,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketConnectionFailed,					0xE098,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketRecvFailed,						0xE099,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketExclusiveRecvNotAvailable,		0xE09A,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketSendFailed,						0xE09B,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketClosed,							0xE09C,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketInvalidPort,						0xE09D,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_socketAppendError,						0xE09E,		kHandling_normal)
	//	0xE0A0 ~ 0xE0AF - 	OpenGL Error
	ML_ERROR_DECLARE(kMLErr_glShaderCreationFailed,					0xE0A0,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_glShaderCompilationFailed,				0xE0A1,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_glProgramCreationFailed,				0xE0A2,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_glShaderLinkFailed,						0xE0A3,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_glAttributeFindingFailed,				0xE0A4,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_glUniformFindingFailed,					0xE0A5,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_glGenBuffersFailed,						0xE0A6,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_glMapBufferFailed, 						0xE0A7, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_glFontLoadingFailed,					0xE0A8, 	kHandling_normal)
	//	0xE0B0 ~ 0xE0BF - 	Module Tracking Error
	ML_ERROR_DECLARE(kMLErr_tstrIdErr_duplicated, 					0xE0B8,		kHandling_normal)
	//	0xE100 ~ 0xE10F -	MTCP Error
	ML_ERROR_DECLARE(kMLErr_mtcp_communicationError,				0xE100,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mtcp_invalidPreamble,					0xE101,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mtcp_invalidPheader,					0xE102,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mtcp_checksumError,						0xE103,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mtcp_unknownCtrlCode,					0xE104,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mtcp_unexpectedPayloadSize,				0xE105,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mtcp_memoryAllocationFailed,			0xE106,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mtcp_test_evaluation_error,				0xE107,		kHandling_normal)
	//	0xE700 ~ 0xE7FF - 	MesaCal Error
	ML_ERROR_DECLARE(kMLErr_mesaCal_getCalibrationDataState,		0xE700, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mesaCal_getSignedCalibrationData,		0xE701,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mesaCal_invalidSyscfgSize,				0xE702,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mesaCal_writeSystemConfig,				0xE703,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mesaCal_readSystemConfig,				0xE704,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_mesaCal_syscfgMemcmp,					0xE705,		kHandling_normal)
	//	Probe Tester
	ML_ERROR_DECLARE(kMLErr_ProbeOOS_Flat_carrier,					0xE720,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ProbeOOS_Flat_blockSpanRatio,			0xE721,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ProbeOOS_Line_carrier,					0xE722,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ProbeOOS_Line_feature,					0xE723,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_ProbeOOS_Line_FMR,						0xE724,		kHandling_normal)
	//	0xE800 ~ 0xE80F	-	fixture
	ML_ERROR_DECLARE(kMLErr_fixtLoadCellNotAvailable,				0xE7FE,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtMotorNotAvailable,					0xE7FF,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtCommunicationError,					0xE800,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtModBus_crc_error,					0xE801,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtAlarmActivated,						0xE802,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtNotInitialized,						0xE803,		kHandling_normal)	
	ML_ERROR_DECLARE(kMLErr_fixtUnknownFixtureStat,					0xE804,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtActionFailed,						0xE805,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtActionTimeout,						0xE806,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtThreadCreationFail,					0xE807,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtInvalidCondition,					0xE808,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtInvalidRequest,						0xE809,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtProbeNotReady,						0xE80A,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtInAction,							0xE80B,		kHandling_normal)
    ML_ERROR_DECLARE(kMLErr_fixtInvalidRegAddr,						0xE80C,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtInvalidRspLeng,						0xE80D,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtInvalidRspCrc,						0xE80E,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fixtInvalidRspFormat,					0xE80F,		kHandling_normal)
	//	0xE810 ~ 0xE81F - 	FDR Error
	ML_ERROR_DECLARE(kMLErr_fdrDataAllocation,						0xE810, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdrCreateInstance,						0xE811, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdrAppendPermissionsString,				0xE812, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_fdrCreation,							0xE813, 	kHandling_normal)
	//	0xE820 ~ 0xE82F - 	factory support
	ML_ERROR_DECLARE(kMLErr_pdcaLogCopyFailed,						0xE822, 	kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_calTableSetFailed, 						0xE827,		kHandling_normal)
	//	0xE830 ~ 0xE83F	-	syscfg
	ML_ERROR_DECLARE(kMLErr_syscfgNoKey,							0xE830,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_syscfgNoSpace,							0xE831,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_syscfgAddKeyFailed,						0xE832,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_syscfgDeleteKeyFailed,					0xE833,		kHandling_normal)
	//	0xE840 ~ 0xE85F	-	instant pudding
	ML_ERROR_DECLARE(kMLErr_IP_UUTStart_failed,						0xE840,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_UUTDone_failed,						0xE841,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_UUTCommit_failed,					0xE842,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_UUTNotStarted,						0xE843,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_addAttribute_failed,					0xE844,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_addBlob_failed,						0xE845,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_addResult_failed,					0xE846,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_testSpec_setTestName_failed,			0xE847,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_testSpec_setSubTestName_failed,		0xE848,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_testSpec_setPriority_failed,			0xE849,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_testSpec_setUnit_failed,				0xE84A,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_testSpec_setLimits_failed,			0xE84B,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_testResult_setValue_failed,			0xE84C,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_testResult_setResult_failed,			0xE84D,		kHandling_normal)
	ML_ERROR_DECLARE(kMLErr_IP_testResult_setMessage_failed,		0xE84E,		kHandling_normal)

	//	0xFFFF - unknown error
	ML_ERROR_DECLARE(kMLErr_unknown, 								0xFFFF, 	kHandling_normal)
} ML_ERROR_TABLE_END;

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus
	uint16_t mlError_getErrorTableSize();
	//		description:
	//			get whole predefined MesaLibrary Error table size
	//		return
	//			size of error table
	
	t_mlError mlError_getErrorCodeFromOrder(uint16_t tableOrder);
	//		description:
	//			get the actual predefined MesaLibrary Error code given error table order
	//		parameter:
	//			tableOrder:	numberic order in predefined error table
	//		return
	//			t_mlError:				MesaLibrary error code
	
	const char* mlError_getErrorString(t_mlError err);
	//		description:
	//			get the string information for certain Error code
	//		parameter:
	//			t_mlError:		predefined Error code
	//		return
	//			string information
	
	t_mlErrorHandlingRule mlError_getHandlingRule(t_mlError err);
	//		description:
	//			get the handling rule for certain Error code
	//		parameter:
	//			t_mlError:		predefined Error code
	//		return
	//			t_mlErrorHandlingRule
	
	void mlError_expandErrorCodes(const char* errStr, uint16_t errCode, t_mlErrorHandlingRule handlingRule);
	//		description:
	//			expand the existing MesaLibrary error code;
	//			overwrite if error code is the same
	//		parameter:
	//			errStr:			error code string
	//			errCode:		error code
	//			handlingRule:	error code handling rule
#ifdef __cplusplus
}
#endif // __cplusplus

#endif//ifndef _ML_ERROR_H_
