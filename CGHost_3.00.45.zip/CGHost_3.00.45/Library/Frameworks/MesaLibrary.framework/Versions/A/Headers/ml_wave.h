//
//  ml_wave.h
//
//  Created by Joon Kwon on 4/20/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_WAVE_H_
#define _ML_WAVE_H_
#include "ml_typedef.h"
#include "ml_log.h"

//http://www-mmsp.ece.mcgill.ca/Documents/AudioFormats/WAVE/WAVE.html

#pragma pack(1)
typedef struct {
	char		RIFF[4];        // 'RIFF' 
	uint32_t	chunkSize;      // RIFF Chunk Size  
	char		WAVE[4];        // 'WAVE'
	//--------------------------
	char		fmt[4];         // 'fmt'
	uint32_t	subchunk1Size;  // Size of the fmt chunk                                
	uint16_t	audioFormat;    // 1=PCM,6=Mu-Law,7=A-Law, 257=IBM Mu-Law, 258=IBM A-Law, 259=ADPCM 
	uint16_t	numOfChan;      // 1=Mono 2=Sterio                   
	uint32_t	samplesPerSec;  // Sampling Frequency in Hz                             
	uint32_t	bytesPerSec;    // bytes per second 
	uint16_t	blockAlign;     // 2=16-bit mono, 4=16-bit stereo 
	uint16_t	bitsPerSample;  // Number of bits per sample      
	//--------------------------
	char		subchunk2ID[4]; // "data"  string   
	uint32_t	subchunk2Size;  // sample data buffer length
} t_mlWaveFileHdr; 
#pragma pack()

static inline void mlWave_printWaveFileHeader(t_mlWaveFileHdr *hdr, char* strBuff){
	sprintf(strBuff                ,"\tRIFF          = \'%c%c%c%c\'\n",hdr->RIFF[0],hdr->RIFF[1],hdr->RIFF[2],hdr->RIFF[3]);
	sprintf(strBuff+strlen(strBuff),"\tchunkSize     = %d\n",hdr->chunkSize);
	sprintf(strBuff+strlen(strBuff),"\tWAVE          = \'%c%c%c%c\'\n",hdr->WAVE[0],hdr->WAVE[1],hdr->WAVE[2],hdr->WAVE[3]);
	sprintf(strBuff+strlen(strBuff),"\tfmt           = \'%c%c%c%c\'\n",hdr->fmt[0],hdr->fmt[1],hdr->fmt[2],hdr->fmt[3]);
	sprintf(strBuff+strlen(strBuff),"\tsubchenk1Size = %d\n",hdr->subchunk1Size);
	sprintf(strBuff+strlen(strBuff),"\taudioFormat	  = 0x%04X - ",hdr->audioFormat);
	switch(hdr->audioFormat){
		case 0x0001:	sprintf(strBuff+strlen(strBuff),"PCM\n"); break;
		case 0x0006:	sprintf(strBuff+strlen(strBuff),"mu-law\n"); break;
		case 0x0007:	sprintf(strBuff+strlen(strBuff),"a-law\n"); break;
		case 0x0101:	sprintf(strBuff+strlen(strBuff),"IBM mu-law\n"); break;
		case 0x0102:	sprintf(strBuff+strlen(strBuff),"IBM a-law\n"); break;
		case 0x0103:	sprintf(strBuff+strlen(strBuff),"ADPCM\n"); break;
		default:		sprintf(strBuff+strlen(strBuff),"unknown\n"); break;
	}
	sprintf(strBuff+strlen(strBuff),"\tnumOfChan     = %d\n",hdr->numOfChan);
	sprintf(strBuff+strlen(strBuff),"\tsamplesPerSec = %d Hz\n",hdr->samplesPerSec);
	sprintf(strBuff+strlen(strBuff),"\tblockAlign    = 0x%04X - ",hdr->blockAlign);
	switch(hdr->blockAlign){
		case 0x0002:		sprintf(strBuff+strlen(strBuff),"16-bit mono\n"); break;
		case 0x0004:		sprintf(strBuff+strlen(strBuff),"16-bit stereo\n"); break;
		default:			sprintf(strBuff+strlen(strBuff),"unknown\n"); break;
	}
	sprintf(strBuff+strlen(strBuff),"\tbitsPerSample = %d\n",hdr->bitsPerSample);
	sprintf(strBuff+strlen(strBuff),"\tdata          = \'%c%c%c%c\'\n",hdr->subchunk2ID[0],hdr->subchunk2ID[1],hdr->subchunk2ID[2],hdr->subchunk2ID[3]);
	sprintf(strBuff+strlen(strBuff),"\tsubchunk2Size = %d [0x%08X]\n",hdr->subchunk2Size,hdr->subchunk2Size);
	int sampleCount = hdr->subchunk2Size/(hdr->bitsPerSample/8)/hdr->numOfChan;
	sprintf(strBuff+strlen(strBuff),"\tdataCount     = %d samples / channel (%.3f sec)\n",sampleCount,sampleCount/(float)hdr->samplesPerSec);
}

#if defined(__cplusplus)

#endif//defined(__cplusplus)
#endif//ifndef _ML_CSV_H_
