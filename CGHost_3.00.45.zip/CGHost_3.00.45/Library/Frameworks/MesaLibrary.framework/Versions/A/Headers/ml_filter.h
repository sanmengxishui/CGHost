//
//  ml_filter.h
//
//  Created by Joon Kwon on 8/27/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_FILTER_H_
#define _ML_FILTER_H_
#include <math.h>
#include "ml_utils.h"

#if defined(__cplusplus)
extern "C" {
#endif
	
	/*	biquad filter
	 *	based on AudioTools/Biquad.h/cpp implementation
	 */
	typedef enum {
		bqType_lowpass = 0,
		bqType_highpass,
		bqType_bandpass,
		bqType_notch,
		bqType_peak,
		bqType_lowshelf,
		bqType_highshelf,
		//
		bqType_max,
	} t_mlBiquadFilterType;
	
	t_mlError mlFltr_biquad(t_mlBiquadFilterType type, float fc, float q, float peak_gain_db, float* sample, uint32_t sampleCnt);
	//		description:
	//			biquad filter - based on the implementation of AudioTools/Biquad.h/cpp
	//			reference: 
	//				http://en.wikipedia.org/wiki/Digital_biquad_filter
	//				http://www.musicdsp.org/showone.php?id=64
	//			the filter is configured by the type, Fc, Q, peak_gain_db, and the filtering is appled to input data, 'sample', 
	//		parameter:
	//			type:			[in]	t_mlBiquadFilterType
	//			fc:				[in]
	//			q:				[in]
	//			peak_gain_db:	[in]
	//			sample:			[in/out] signal to be filtered
	//			sampleCnt:		[in]	data count
	//		return
	//			none

	
#if defined(__cplusplus)
}
#endif

#endif//ifndef _ML_FILTER_H_
