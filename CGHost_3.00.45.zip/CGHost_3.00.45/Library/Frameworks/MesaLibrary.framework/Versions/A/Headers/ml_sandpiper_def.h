//
//  ml_sandpiper_def.h
//
//  Created by Joon Kwon on 2/26/15.
//  Copyright (c) 2015 APPLE. All rights reserved.
//

#ifndef _ML_SANDPIPER_DEF_H_
#define _ML_SANDPIPER_DEF_H_

#pragma mark -
#pragma mark Generic
/***************************************************************************************************
 *	Generic
 */
#define rSP_GET_FW_VERSION			0x8C
//	[SET]	
//		n/a, not defined
//	[GET]	
//		description:
//			read sandpiper board FW version 
//		payload size:
//			2-byte (big-endian) [b0~7: minor version, b8~15: major version]

#define rSP_GET_SP_SN               0x8F
//	[SET]
//		n/a, not defined
//	[GET]
//		description:
//			read sandpiper serial number
//		payload size:
//			max 32bytes serial number

#define rSP_FUNCTION_RETURN			0x79
//	[SET]	
//		n/a, not defined
//	[GET]	
//		description:
//			read the return value of the previous sandpiper function call
//		payload size:
//			1-byte:	error code

#pragma mark -
#pragma mark GPIO
/***************************************************************************************************
 *	GPIO
 */
#define rSP_GPIO_STATUS				0x80
//	[SET]	
//		description:
//			initiate GPIO status actions
//		payload size:
//			uint16_t	[b0] GPIO ID
//						[b1] control
//							0x00	GPO	set LOW
//							0x01	GPO set HIGH
//							0x02	GPI get status
//		note:
//			the excecution result should be checked via rSP_GET_FUNCTION_RETURN
//	[GET]	
//		description:
//			on successful SET rSP_GPIO_STATUS retrieve the GPIO status
//		payload size:
//			uint8_t		[b0] status

#pragma mark -
#pragma mark SPI
/***************************************************************************************************
 *	SPI
 */
#define rSP_SET_SPI_FREQ			0x8A
//		description:
//			set sandpiper spi interface frequncy
//		payload size:
//			1-byte, uint8_t value, 0x01 is 0.1MHz, 0xFF is 25.5MHz

#define rSP_GET_SPI_BUFFER_SIZE		0x8A
//		description:
//			get sandpiper spi buffer
//		payload size:
//			2-byte, uint16_t value, little endian

#define rSP_SPI_COMMAND				0x89
//	[SET]	
//		description:
//			send SPI command
//			the SPI command to be packetized to 62 bytes (64 USB HID packet size - 2 byte header)
//		payload size:	64-byte
//			uint16_t	[b0~1]		the length of receive (MSB indicates 1: the more data to send, 0: send data completedd
//			uint8_t arr	[b2~b63]	SPI send data
//	[GET]	
//		description:
//			read out the SPI response (the read length is specified at [SET]
//		payload size:	64-byte
//			uint8_t		[b0~64]		SPI recv data


#pragma mark -
#pragma mark LDO
/***************************************************************************************************
 *	LDO
 */
#define rSP_LDO_SET					0x83

#define POWER_RAIL_1V8 2
#define POWER_RAIL_3V0 1
#define POWER_RAIL_BST 0
#define POWER_RAIL_RES 3

//	[SET]	
//		description:
//			set LDO output voltage
//		payload size:	64-byte
//			uint16_t	[b0]		LDO ID
//			uint8_t arr	[b1~8]		(double, little endian)	target voltage
//		note:
//			the excecution result should be checked via rSP_GET_FUNCTION_RETURN

#pragma mark -
#pragma mark DMM
/***************************************************************************************************
 *	DMM
 */
#define rSP_DMM_READING				0x82

#define kSP_CMD_DMM_MEASURE_LOW		0	// [action followed]	measure and apply LOW  range coeff
#define kSP_CMD_DMM_MEASURE_HIGH	1	// [action followed]	measure and apply HIGH range coeff
#define kSP_CMD_DMM_SET_SUB_RANGE	2	// [configure only ]	[SPv5 or later] specify the sub-range
#define kSP_CMD_DMM_RAW_ADC_GND		3	// [action followed]	return raw ADC reading with GND
#define kSP_CMD_DMM_RAW_ADC_V_I		4	// [action followed]	return raw ADC value (voltage & current)
#define kSP_CMD_DMM_RAW_ADC_RES		5	// [action followed]	return raw ADC value (resistance)
#define kSP_CMD_DMM_SET_RANGE_LOW	6	// [configure only ]	set relay to low range
#define kSP_CMD_DMM_SET_RANGE_HIGH	7	// [configure only ]	set relay to high range
#define kSP_CMD_DMM_SET_RANGE_AUTO	8	// [action followed]	let FW select the range (low/high)
#define kSP_CMD_DMM_SAMPLING_COUNT	9	// [configure only ]	set FW sampling count for averaging

//		description:
//			specifiy the channel to be measured and the range of the measurement
//
//		CONFIGURE SAMPLING RATE (optional)
//			specify the sampling rate (averaging).
//			[FW default = 1]
//			2-byte
//			uint8_t		[b0]	data sample count
//						[b1]	kSP_CMD_DMM_SAMPLING_COUNT
//		CONFIGURE RANGE (relay setup, optional)
//			specify the range of the measurement
//			[FW default = HIGH range]
//			2-byte
//			uint8_t		[b0]	channel
//						[b1]	kSP_CMD_DMM_RANGE_LOW / kSP_CMD_DMM_SET_RANGE_HIGH / kSP_CMD_DMM_SET_RANGE_AUTO
//			[note]
//				kSP_CMD_DMM_SET_RANGE_AUTO -> FW will detect the range.
//
//		START MEASUREMENT
//			2-byte
//			uint8_t		[b0]	channel
//						[b1]	kSP_CMD_DMM_MEASURE_LOW
//								kSP_CMD_DMM_MEASURE_HIGH
//								kSP_CMD_DMM_RAW_ADC_GND
//								kSP_CMD_DMM_RAW_ADC_V_I
//								kSP_CMD_DMM_RAW_ADC_RES
//		note:
//			the excecution result should be checked via rSP_GET_FUNCTION_RETURN
//	[GET]
//		description:
//			read out the DMM measurement data (t_mlSandpiper_dmm_reading)
//		payload size:	32-byte
//			uint8_t		[b0~31]		dmm measurement data


#pragma pack(1)
typedef struct{
	uint16_t	ADvol;
	uint16_t	ADcur;
	uint16_t	ADres1;
	uint16_t	ADres2;
	double		voltage;
	double		current;
	double		resistance;
} t_mlSandpiper_dmm_reading;
#pragma pack()

//	[SET]
#define rSP_DMM_CAL_VOLTAGE_SET_DAC 0x84
#define rSP_DMM_CAL_DATA_STORE      0x85
#define rSP_DMM_CAL_DATA_RETRIEVE   0x86
#define rSP_SAVE_DATA_TO_BUFFER     0x87
#define rSP_GET_DATA_FROM_BUFFER    0x88
#define rSP_SET_DATA_TO_BUF_BULK	0xB0
#define rSP_GET_DATA_FROM_BUF_BULK	0xB1

#define COMP_NUMBER 128

typedef struct
{
    UInt16 dac;
    UInt16 comp;
}t_comp;

//dmm cur comp data
typedef struct
{
    t_comp cur_comp[2][3][COMP_NUMBER]; //range, powerRail, com points
}t_dmmCur_comp;

//dmm vol comp data
typedef struct
{
    t_comp vol_comp[3][COMP_NUMBER];
}t_dmmVol_comp;

//dmm res comp data
typedef struct
{
    t_comp res_comp[COMP_NUMBER];
}t_dmmRes_comp;

typedef struct
{
    UInt8 dac;
    double volt;
}t_dac;

typedef struct
{
    t_dac volt_dac[3][COMP_NUMBER];
}t_dac_table;

typedef struct
{
    UInt8 cal_flag;
    UInt8 dac_1v8;
    UInt8 dac_1v9;
    UInt8 dac_2v0;
    UInt8 dac_2v9;
    UInt8 dac_3v0;
    UInt8 dac_3v1;
    UInt8 dac_11v0;
    UInt8 dac_11v3;
    UInt8 dac_11v6;
    UInt8 dac_15v5;
    UInt8 dac_16v0;
    UInt8 dac_16v5;
    UInt8 target_1v8;
    UInt8 target_3v0;
    UInt8 target_bst;
    double target_vol_1v8;
    double target_vol_3v0;
    double target_vol_bst;
    t_dmmCur_comp cur_comp;
    t_dmmVol_comp vol_comp;
    t_dmmRes_comp res_comp;
    char sn[32];
    t_dac_table voltDacTable;
    UInt8 dac_17v0;
    UInt8 dac_17v5;
    UInt8 dac_18v0;
    UInt8 dac_18v5;
    UInt8 dac_19v0;
    UInt8 dac_19v5;
    UInt8 dac_20v0;
}t_dmm_cal_data;

#pragma mark -
#pragma mark FIXTURE
/***************************************************************************************************
 *	Fxiture
 */

#pragma mark -
#pragma mark ADC
/***************************************************************************************************
 *	ADC
 */
#define rSP_ADC_MEASURE		0x81

#pragma mark -
#pragma mark I2C
/***************************************************************************************************
 *	I2C
 */
#define kSP_EEPROM_WRITE_NOW    1
#define kSP_EEPROM_READ_NOW     2
#define kSP_EEPROM_LOAD_DATA    3
#define kSP_EEPROM_WRITE_NOW8    4
#define kSP_EEPROM_READ_NOW8     5

#define rSP_MESA_I2C		0x8B

#pragma mark -
#pragma mark Relay Board
/***************************************************************************************************
 *	Relay Board for connection between SPv3 and DUT
 */
#define rSP_RELAY_I2C		0x8D

typedef enum{
	kSpRelayCtrl_none				= 0x00,
	kSpRelayCtrl_i2cScl_i2cSda		= 0x01,
	kSpRelayCtrl_1v8_hall0			= 0x02,
	kSpRelayCtrl_extInt_spiClk		= 0x04,
	kSpRelayCtrl_spiMiso_spiMosi	= 0x08,
	kSpRelayCtrl_3v0				= 0x10,
	kSpRelayCtrl_gnd				= 0x20,
	kSpRelayCtrl_16v0_boostOn		= 0x40,
	kSpRelayCtrl_menuKey_hall1		= 0x80,
	kSpRelayCtrl_all				= 0xFF,
} t_mlSpRelayCtrl;

#pragma mark -
#pragma mark SP GPIO setup info
/***************************************************************************************************
 *	Sandpiper GPIO setup info
 */
#define	PA00			0
#define	PA01			1
#define	PA02			2
#define	PA03			3
#define	PA04			4
#define	PA05			5
#define	PA06			6
#define	PA07			7
#define	PA08			8
#define	PA09			9
#define	PA10			10
#define	PA11			11
#define	PA12			12
#define	PA13			13
#define	PA14			14
#define	PA15			15
#define	PA16			16
#define	PA19			19
#define	PA20			20
#define	PA21			21
#define	PA22			22
#define	PA23			23
#define	PA24			24
#define	PA25			25
#define	PA26			26
#define	PA27			27
#define	PA28			28
#define	PA29			29
#define	PB00			32
#define	PB01			33
#define	PB02			34
#define	PB03			35
#define	PB04			36
#define	PB05			37
#define	PB06			38
#define	PB07			39
#define	PB08			40
#define	PB09			41
#define	PB10			42
#define	PB11			43
#define	PB12			44
#define	PB13			45
#define	PB14			46
#define	PB15			47
#define	PB16			48
#define	PB17			49
#define	PB18			50
#define	PB19			51
#define	PB20			52
#define	PB21			53
#define	PB22			54
#define	PB23			55
#define	PB24			56
#define	PB25			57
#define	PB26			58
#define	PB27			59
#define	PB28			60
#define	PB29			61
#define	PB30			62
#define	PB31			63
#define	PC00			64
#define	PC01			65
#define	PC02			66
#define	PC03			67
#define	PC04			68
#define	PC05			69
#define	PC06			70
#define	PC07			71
#define	PC08			72
#define	PC09			73
#define	PC10			74
#define	PC11			75
#define	PC12			76
#define	PC13			77
#define	PC14			78
#define	PC15			79
#define	PC16			80
#define	PC17			81
#define	PC18			82
#define	PC19			83
#define	PC20			84
#define	PC21			85
#define	PC22			86
#define	PC23			87
#define	PC24			88
#define	PC25			89
#define	PC26			90
#define	PC27			91
#define	PC28			92
#define	PC29			93
#define	PC30			94
#define	PC31			95
#define	PD00			96
#define	PD01			97
#define	PD02			98
#define	PD03			99
#define	PD04			100
#define	PD05			101
#define	PD06			102
#define	PD07			103
#define	PD08			104
#define	PD09			105
#define	PD10			106
#define	PD11			107
#define	PD12			108
#define	PD13			109
#define	PD14			110
#define	PD15			111
#define	PD16			112
#define	PD17			113
#define	PD18			114
#define	PD19			115
#define	PD20			116
#define	PD21			117
#define	PD22			118
#define	PD23			119
#define	PD24			120
#define	PD25			121
#define	PD26			122
#define	PD27			123
#define	PD28			124
#define	PD29			125
#define	PD30			126

#define	GPIO1			PC25
#define	GPIO2			PC26
#define	GPIO3			PC29
#define	GPIO4			PC30
#define	GPIO5			PC31
#define	GPIO6			PD05
#define	GPIO7			PD06
#define	GPIO8			PD07
#define	GPIO9			PD08
#define	GPIO10			PD09
#define	GPIO11			PD10
#define	GPIO12			PD11
#define	GPIO13			PD12
#define	GPIO14			PD13
#define	GPIO15			PD14
#define	GPIO16			PD15
#define	GPIO17			PD16
#define	GPIO18			PD17
#define	GPIO19			PD18
#define	GPIO20			PD19
#define	GPIO21			PD20
#define	GPIO22			PD21
#define	GPIO23			PD22
#define	GPIO24			PD23
#define	GPIO25			PD24
#define	GPIO26			PD25
#define	GPIO27			PD26
#define	GPIO28			PD27
#define	GPIO29			PD28
#define	GPIO30			PD29
#define	GPIO31			PD30
#define	GPIO32			PC24
#define	GPIO33			PC23
#define	GPIO34			PC22
#define	GPIO35			PC21
#define	GPIO36			PC20
#define	GPIO37			PC19
#define	GPIO38			PC18
#define	GPIO39			PC17
#define	GPIO40			PC14
#define	GPIO41			PC13
#define	GPIO42			PC12
#define	GPIO43			PC11
#define	GPIO44			PC10
#define	GPIO45			PB04
#define	GPIO46			PB05
#define	GPIO47			PB06
#define	GPIO48			PB07
#define	GPIO49			PA27
#define	GPIO50			PA26
#define	GPIO51			PA25
#define	GPIO52			PA24
#define	GPIO53			PA23
#define	GPIO54			PA22
#define	GPIO55			PA21
#define	GPIO56			PA20

#define	MCU_AD1			PA04
#define	MCU_AD2			PA05
#define	MCU_AD3			PA06
#define	MCU_AD4			PA07
#define	MCU_AD5			PA08
#define	MCU_AD6			PA09
#define	MCU_AD7			PA10
#define	MCU_AD8			PA11

#define	GPO_1			GPIO1
#define	GPO_2			GPIO2
#define	GPO_3			GPIO3
#define	GPO_4			GPIO4
#define	GPO_5			GPIO5
#define	GPO_6			GPIO6
#define	GPO_7			GPIO7
#define	GPO_8			GPIO8
#define	GPO_9			GPIO9
#define	GPO_10			GPIO10
#define	GPO_11			GPIO11
#define	GPO_12			GPIO12
#define	GPO_13			GPIO13
#define	GPO_14			GPIO14
#define	GPO_15			GPIO15
#define	GPO_16			GPIO16
#define	GPO_17			GPIO17
#define	GPO_18			GPIO18
#define	GPO_19			GPIO19
#define	GPO_20			GPIO20
#define	GPO_21			GPIO21
#define	GPO_22			GPIO22
#define	GPO_23			GPIO23
#define	GPO_24			GPIO24
#define	GPO_25			GPIO25
#define	GPO_26			GPIO26
#define	GPO_27			GPIO27
#define	GPO_28			GPIO28
#define	GPO_29			GPIO29
#define	GPO_30			GPIO30
#define	GPO_31			GPIO31
#define	GPO_32			GPIO32

#define	GPI_16			GPIO33
#define	GPI_15			GPIO34
#define	GPI_14			GPIO35
#define	GPI_13			GPIO36
#define	GPI_12			GPIO37
#define	GPI_11			GPIO38
#define	GPI_10			GPIO39
#define	GPI_9			GPIO40
#define	GPI_8			GPIO41
#define	GPI_7			GPIO42
#define	GPI_6			GPIO43
#define	GPI_5			GPIO44
#define	GPI_4			GPIO45
#define	GPI_3			GPIO46
#define	GPI_2			GPIO47
#define	GPI_1			GPIO48
#define	GPI_24			GPIO49
#define	GPI_23			GPIO50
#define	GPI_22			GPIO51
#define	GPI_21			GPIO52
#define	GPI_20			GPIO53
#define	GPI_19			GPIO54
#define	GPI_18			GPIO55
#define	GPI_17			GPIO56

#define RELAY_CONTROL_1	GPIO30
#define RELAY_CONTROL_2	GPIO29
#define RELAY_CONTROL_3	GPIO28
#define RELAY_CONTROL_4	GPIO27
#define RELAY_CONTROL_5	GPIO26
#define RELAY_CONTROL_7	GPIO25
#define RELAY_CONTROL_6	GPIO24
#define RELAY_CONTROL_8	GPIO23

#define OPTICAL_SENSOR	GPIO22
#define VACUUM_SENSOR	GPIO21
#define X_R_SENSOR		GPIO18
#define X_L_SENSOR		GPIO19
#define X_U_SENSOR		GPIO17
#define X_D_SENSOR		GPIO20

#define LED1			GPIO43
#define LED2			GPIO44
#define LED3			GPIO41
#define LED4			GPIO42
#define LED5			GPIO40
#define LED6			GPIO39
#define LED7			GPIO38
#define LED8			GPIO37
#define BUZZER			GPIO34

#define ACTUATOR_1		GPIO4
#define ACTUATOR_2		GPIO5
#define ACTUATOR_3		GPIO6
#define ACTUATOR_4		GPIO7
#define ACTUATOR_5		GPIO8
#define ACTUATOR_6		GPIO9
#define ACTUATOR_7		GPIO10
#define ACTUATOR_8		GPIO11

//test software definition
#define ACT_POGO_BLOCK   ACTUATOR_1
#define ACT_LATCH_ARM    ACTUATOR_2
#define ACT_VACUUM       ACTUATOR_3
#define ACT_HOME_BUTTON  ACTUATOR_4

#define RELAY_ESD_TEST   RELAY_CONTROL_1
#define RELAY_DR_TEST    RELAY_CONTROL_2

#define SW1				GPIO16
#define SW2				GPIO15
#define SW3				GPIO14
#define SW4				GPIO13

#define SW_REL			SW1
#define SW_VOLT			SW2
#define SW_BRD_DETECT	GPIO50
#define SW_BRD_CAL		SW4

#define HALL_0			GPIO51
#define HALL_1			GPIO52

#define MCU_STATUS		PB16

//IO customization
#define	DR_UPPER_LIMIT		PD30
#define	ESD_UPPER_LIMIT		PC24
#define	POWER_CTRL_1V8		PA12
#define	POWER_CTRL_3V0		PA13
#define	POWER_CTRL_BST		PB03
#define	MESA_MENU_KEY_OUT	PB26
#define	MESA_MENU_KEY_IN	HALL_0
#define	MESA_SPI_INT		PB18
#define	MESA_FD_INT			PB26
//end of SPV3

#endif//ifndef _ML_SANDPIPER_DEF_H_
