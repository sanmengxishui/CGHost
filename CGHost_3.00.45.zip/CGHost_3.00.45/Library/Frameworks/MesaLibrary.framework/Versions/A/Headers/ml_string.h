//
//  ml_string.h
//
//  Created by Joon Kwon on 8/27/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_STRING_H_
#define _ML_STRING_H_
#include "ml_utils.h"

#if defined(__cplusplus)
extern "C" {
#endif
	
#pragma mark -
#pragma mark string tools
	char*		mlStr_getSizeString(uint32_t size);
	uint32_t	mlStr_checkTextCount(const char* ptr, const char* txt);
	char*		mlStr_skipWord(const char* ptr);
	char*		mlStr_skipSpace(const char* ptr);
	char*		mlStr_goAfter(const char* ptr, const char* txt);
	char*		mlStr_goNextWord(const char* ptr);
	char*		mlStr_goNextLine(const char* ptr);
	t_mlError	mlStr_getNextString(char* text, char* delimiter, char* textBuff)__attribute__((deprecated("Unsafe! use mlStr_getNextStringWithLimit")));
	t_mlError	mlStr_getNextStringWithLimit(char* text, char* delimiter, char* textBuff, int textBuffLen);
	t_mlError	mlStr_getItemString(char* strLineTitle,char* strLineData,char* strDelimiter,char* strItemName,char* strBuff);
	char*		mlStr_goLastText(const char* ptr, const char* txt);

	void		mlStr_upperCaseString(char* ptr);
	void		mlStr_lowerCaseString(char* ptr);

	char*		mlStr_scanInt_1D(char* ptr, int* buff, int width);
	char*		mlStr_scanInt_2D(char* ptr, int* buff, int width, int height, bool flip);
	char*		mlStr_scanFloat_1D(char* ptr, float* buff, int width);
	char*		mlStr_scanFloat_2D(char* ptr, float* buff, int width, int height, bool flip);
#if defined(__cplusplus)
}
#include <string>
#include <vector>
char* mlStr_strstr(const std::string&, const std::string&);
char* mlStr_strcasestr(const std::string&, const std::string&);
char* mlStr_goAfter(const std::string&, const std::string&);
std::vector<std::string> mlStr_split(const std::string& inputStr, const std::string& delimitor);
#endif

#endif//ifndef _ML_STRING_H_
