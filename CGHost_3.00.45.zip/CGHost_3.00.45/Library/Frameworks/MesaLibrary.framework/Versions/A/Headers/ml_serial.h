//
//  ml_Serial.h
//
//  Created by Joon Kwon on 10/8/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_SERIAL_H_
#define _ML_SERIAL_H_
#include <sys/termios.h>
#include "ml_typedef.h"
#include "ml_usb.h"

// serial port format	[DATA_BIT][PARITY][STOP_BIT]
typedef enum{
	k_mlSerialFormat_8N1 = 0,
	k_mlSerialFormat_8O1,
	k_mlSerialFormat_8E1,
	k_mlSerialFormat_8N2,
	k_mlSerialFormat_8O2,
	k_mlSerialFormat_8E2,
	k_mlSerialFormat_7N1,
	k_mlSerialFormat_7O1,
	k_mlSerialFormat_7E1,
} t_mlSerialFormat;

typedef enum{
	kModBusCmd_read			= 0x03,
	kModBusCmd_writeSngle	= 0x06,
	kModBusCmd_writeMulti	= 0x10,
	kModBusCmd_diagnose		= 0x08,
} t_mlModBusCommand;

// modbus function values, http://en.wikipedia.org/wiki/Modbus
typedef enum{
	// 8-bit, Physical Discrete Inputs
	kModBusFunction_readDiscreteInputs			= 2,
	// 8-bit, Internal Bits or Physical Coils
	kModBusFunction_readCoils					= 1,
	kModBusFunction_writeSingleCoil				= 5,
	kModBusFunction_writeMultipleCoils			= 15,
	// 16-bit, physical input registers
	kModBusFunction_readInputRegister			= 4,
	// 16-bit, internal registers or physical output registers
	kModBusFunction_readHoldingRegisters		= 3,
	kModBusFunction_writeSingleRegister			= 6,
	kModBusFunction_writeMultipleResisters		= 16,
	kModBusFunction_readWriteMultipleRegisters	= 23,
	kModBusFunction_maskWriteRegister			= 22,
	kModBusFunction_readFifoQueue				= 24,
	// file record access
	kModBusFunction_readFileRecord				= 20,
	kModBusFunction_writeFileRecord				= 21,
	// diagnostics
	kModBusFunction_readExceptionStatus			= 7,
	kModBusFunction_diagnostic					= 8,
	kModBusFunction_getComEventCounter			= 11,
	kModBusFunction_getComEventLog				= 12,
	kModBusFunction_reportSlaveId				= 17,
	kModBusFunction_readDeviceIdentification	= 43,
} t_mlModBusFunction;

typedef enum serialStopBit_enum{
	kOneStopBit = 0,
	kTwoStopBit
} t_mlSerialStopBit;

typedef enum serialParity_enum{
	kNoParity = 0,
	kOddParity,			//	1
	kEvenParity
} t_mlSerialParity;


#if TARGET_OS_MAC
#if !TARGET_OS_IPHONE
#if defined(__cplusplus)
/***************************************************************************************************
 *	CML_serial
 *	Description:	serial port
 */
#pragma mark -
#pragma mark CML_serial

/*	IML_SerialCallback	CML_serial call back interface
 */
struct IML_SerialCallback{
	virtual void onSerialDisconnected(uint32_t name, t_mlUsbDevInfo& devInfo) = 0;
	//		description:
	//			called when the serial port is discomnnected
	//			it is recommended to 'DELETE' the USB device instance on this call.
	//		parameter:
	//			name:	the serial port 'name' set through setCallback function.
	//		return
	//			none
};

/*	CML_serial
 */
class CML_serial: protected CML_baseObject, IML_usbDevCallback {
protected:
	CML_usbDev*				_usbDev;
	uint32_t				_name;
	//
	std::mutex				_mtx;
	//
	std::string				_bsdPath;
	int						_fd;
	struct termios*			_pTtyAttr_original;
	uint8_t*				_sendBuff;
	uint32_t				_sendBuffSize;
	uint32_t				_baudRate;
	t_mlSerialFormat		_format;
	//
	IML_SerialCallback*		_callback;
public:
	CML_serial();
	virtual ~CML_serial();
	t_mlError setLogManager(CML_logManager* lm);
protected:
	//IML_usbDevCallback
	void	onUsbDevDisconnected(uint32_t name, t_mlUsbDevInfo& devInfo);
public:
	void	setCallback(uint32_t name, IML_SerialCallback* callback);
public:
	t_mlError	Open();
	//		description: 
	//			open serial port
	//		return:
	//			t_mlError value
	void		Close();
	//		description: 
	//			close serial port
	t_mlError	clear_readBuffer();
	//		description: 
	//			readout the read buffer
	//		return:
	//			t_mlError value
public:
	t_mlError	Write(uint8_t* sendBuff, uint32_t sendLeng);
	//		description:
	//			send raw bytes over serial port
	//		param:
	//			sendBytes	[in]	send buffer
	//			sendLeng	[in]	sending buffer length
	//		return:
	//			t_mlError value
	t_mlError	Read(uint8_t* recvBuff, uint32_t* pRecvLeng, uint32_t timeoutMsec = 1000);
	//		description:
	//			read serial port for raw bytes
	//			it is non-blocking call and the output of pRecvLeng can be zero
	//		param:
	//			recvBuff:	[out]	receive buffer
	//			pRecvLeng:	[in]	specifies the size of the receive buffer
	//						[out]	the legnth of the data received (one time)
	//		return:
	//			t_mlError value
	t_mlError	Write(char* format, ...);
	//		description: 
	//			send string over serial port
	//		param:
	//			format		[in]	same as printf,
	//			the total string length should be less than "bufferSizeKB" at "create" method call
	//		return:
	//			t_mlError value
	t_mlError	Read(char* recvBuff, uint32_t* pRecvLeng, uint32_t timeoutMsec = 1000);
	//		description: 
	//			read serial port and search for the delimiter
	//			it is non-blocking call and the output of pRecvLeng can be zero
	//		param:
	//			recvBuff:	[out]	receive buffer
	//			pRecvLeng:	[in]	specifies the size of the receive buffer
	//						[out]	the legnth of the data received (one time)
	//		return:
	//			t_mlError value
	t_mlError	Read(char* recvBuff, uint32_t* pRecvLeng, char* delimiter, uint32_t timeoutMsec = 1000, uint32_t byteDelayUs = 0);
	//		description: 
	//			read serial port and search for the delimiter
	//			non-blocking call
	//		param:
	//			recvBuff:	[out]	receive buffer
	//			pRecvLeng:	[in]	specifies the size of the receive buffer
	//						[out]	the legnth of the data received (one time)
	//			delimiter:	[in]	the string that indicates the end of the message
	//			timeoutMsec:[in]	timeout in millisecond
	//			byteDelayUs [in]	the delay (in µsec) before read the next one byte, 
	//								when byteDelay==0, then it will try 1/4 of the byte duration calculated from baud rate
	//		return:
	//			t_mlError value
	t_mlError	Write_modBus_rtu(uint8_t address, uint8_t function, void* data, int dataLeng);
	//		description: 
	//			write modbus message [RTU] from serial port
	//		param:
	//			address		[in]	target address
	//			function	[in]	function code
	//			data		[in]	data buffer
	//			dataLeng	[in]	data length
	//
	//			the total string length should be less than "bufferSizeKB" at "create" method call
	//		return:
	//			t_mlError value
	t_mlError	Read_modBus_rtu(uint8_t* recvBuff, uint32_t* pRecvLeng, uint32_t timeoutMsec = 1000);
	//		description: 
	//			receive modbus message [ASCII] from serial port
	//		param:
	//			recvBuff	[out]	receive buffer
	//			pRecvLeng	[in]	the receive buffer size
	//						[out]	received data size
	//			timeoutMsec	[in]	timeout in millisecond
	//		return:
	//			t_mlError value
	t_mlError	Write_modBus_ascii(uint8_t address, uint8_t function, uint8_t* data, int dataLeng);
	//		description: 
	//			write modbus message [ASCII] from serial port
	//		param:
	//			address		[in]	target address
	//			function	[in]	function code
	//			data		[in]	data buffer
	//			dataLeng	[in]	data length
	//
	//			the total string length should be less than "bufferSizeKB" at "create" method call
	//		return:
	//			t_mlError value
	t_mlError	Read_modBus_ascii(uint8_t* recvBuff, uint32_t* pRecvLeng, uint32_t timeoutMsec = 1000);
	//		description: 
	//			receive modbus message [ASCII] from serial port
	//		param:
	//			recvBuff	[out]	receive buffer
	//			pRecvLeng	[in]	the receive buffer size
	//						[out]	received data size
	//			timeoutMsec	[in]	timeout in millisecond
	//		return:
	//			t_mlError value
	t_mlError	Flush(uint8_t direction);
	//		description: 
	//			flush serial port
	//		param:
	//			direction:	0: in/read
	//						1: out/send
	//						2: both
	//		return:
	//			t_mlError value
public:
	int8_t		dtr_get();
	//		description: 
	//			get DTR
	//		return:
	//			-1: fail, 0/1: DTR level
	t_mlError	dtr_set(bool state);
	//		description: 
	//			Set DTR
	//		parameter:
	//			state	0 or 1
	//		return:
	//			t_mlError value
	int8_t		dsr_get	();
	//		description: 
	//			get DSR
	//		return:
	//			-1: fail, 0/1: DSR level
	t_mlError	dsr_set(bool state);
	//		description: 
	//			Set DSR
	//		parameter:
	//			state	0 or 1
	//		return:
	//			t_mlError value
	int8_t		cts_get	();
	//		description: 
	//			get CTS
	//		return:
	//			-1: fail, 0/1: CTS level
	t_mlError	cts_set(bool state);
	//		description: 
	//			Set CTS
	//		parameter:
	//			state	0 or 1
	//		return:
	//			t_mlError value
	int8_t		rts_get	();
	//		description: 
	//			get RTS
	//		return:
	//			-1: fail, 0/1: RTS level
	t_mlError	rts_set(bool state);
	//		description: 
	//			Set RTS
	//		parameter:
	//			state	0 or 1
	//		return:
	//			t_mlError value
public:
	static CML_serial* create(const char* matchingBsdPath ,uint32_t baudRate, t_mlSerialFormat format, uint8_t bufferSizeKB = 4);
	//		[STATIC HELPER FUNCTION]
	//		description:
	//			create CML_serial object from bsdPathName
	//		parameter:
	//			baudRate:		[in]	baud rate in Bps
	//			format:			[in]	format in t_mlSerialFormat
	//			bufferSizeKB:	[in]	buffer size (in KByte) fo the serial communication, default 4KByte
	//			matchingBsdPath:[in]	expected bsdPathName, create fail if not matching
	//		return:
	//			the pointer to the new CML_serial object
	static CML_serial* create(CML_usbDev* pUsbDev, uint32_t baudRate, t_mlSerialFormat format, uint8_t bufferSizeKB = 4, const char* matchingBsdPath = NULL);
	//		[STATIC HELPER FUNCTION]
	//		description:
	//			create CML_serial object from bsdPathName
	//		parameter:
	//			pUsbDev:	valid pointer to CML_usbDev or its decendents
	//			baudRate:		[in]	baud rate in Bps
	//			format:			[in]	format in t_mlSerialFormat
	//			bufferSizeKB:	[in]	buffer size (in KByte) fo the serial communication, default 4KByte
	//			matchingBsdPath:[in]	expected bsdPathName, create fail if not matching
	//		return:
	//			the pointer to the new CML_serial object
	static CML_serial* create(uint16_t vndrID, uint16_t prodID, uint32_t locationID,
							  uint32_t baudRate, t_mlSerialFormat format, uint8_t bufferSizeKB = 4, const char* matchingBsdPath = NULL);
	//		[STATIC HELPER FUNCTION]
	//		description:
	//			create CML_serial object from bsdPathName
	//		parameter:
	//			vndrID:			[in]	usb device vendor ID
	//			prodID:			[in]	usb device product ID
	//			locationID:		[in]	usb device location ID (can be 0x00 for not checking location ID)
	//			baudRate:		[in]	baud rate in Bps
	//			format:			[in]	format in t_mlSerialFormat
	//			bufferSizeKB:	[in]	buffer size (in KByte) fo the serial communication, default 4KByte
	//			matchingBsdPath:[in]	expected bsdPathName, create fail if not matching
	//		return:
	//			the pointer to the new CML_serial object
};

#endif//defined(__cplusplus)
#endif//!TARGET_OS_IPHONE
#endif//TARGET_OS_MAC
#endif//ifndef _ML_SERIAL_PORT_H_
