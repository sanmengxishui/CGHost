//
//  ml_futekLoadCell.h
//
//  Created by Joon Kwon on 10/8/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_FUTEK_LOAD_CELL_H_
#define _ML_FUTEK_LOAD_CELL_H_
#include <pthread.h>
#include "ml_serial.h"
#include "ml_utils.h"

#if TARGET_OS_MAC
#if !TARGET_OS_IPHONE
#if defined(__cplusplus)
/***************************************************************************************************
 *	CML_futekLoadCell
 *	Description:	serial port
 */
#pragma mark -
#pragma mark CML_futekLoadCell

/*	IML_futekLoadCellCallback	CML_futekLoadCell call back interface
 */
struct IML_futekLoadCellCallback{
	virtual void onFutecLoadCellDisconnected(uint32_t name, t_mlUsbDevInfo& devInfo) = 0;
	//		description:
	//			called when the futec loadcell is disconnected
	//			it is recommended to 'DELETE' the USB device instance on this call.
	//		parameter:
	//			name:	the loadcell 'name' set through setCallback function.
	//		return
	//			none
};

/*	CML_futekLoadCell
 */
class CML_futekLoadCell: public CML_baseObject, IML_SerialCallback {
protected:
	IML_futekLoadCellCallback* _callback;
	bool			_isRunning;
	bool			_dataValid;
	bool			_waitForStart;
	double			_waitTimeout;
	double			_startTime;
	double			_stopTime;
	//
	char*			_numStrBuffer;
	char*			_stringBuffer;
	uint64_t		_stringBufferLen;
	uint64_t		_maxStringBufferLen;
	bool			_allowExtCtrl;
	//
	float			_forceReading_current;
	CML_fifo*		_fifo;
	int32_t			_dataCount;
	int32_t			_discardCount;
	//
	uint32_t		_byteDelayUsec;
	pthread_mutex_t	_mtx_read;
	pthread_t		_thread;
	//
	CML_serial*			_serial;
public:
	CML_futekLoadCell();
	CML_futekLoadCell(CML_logManager* lm);
	virtual ~CML_futekLoadCell();
	t_mlError setLogManager(CML_logManager* lm);
	bool isClassOf(const char* className){return CML_baseObject::isClassOf(className);};
protected:
	//IML_serialCallback
	void onSerialDisconnected(uint32_t name, t_mlUsbDevInfo& devInfo);
public:
	void setCallback(uint32_t name, IML_futekLoadCellCallback* callback);
	//		description:
	//			set the call back 
	//		parameter:
	//			name:		uint32_t type value that will be used for identifying sandpiper object
	//			callback:	pointer to a class instance that supports IML_futekLoadCellCallback interface
	//		return
	//			t_mlError value
public:
	t_mlError	OpenStreaming(uint32_t dataPointsTarget, double waitTimeout = 5.0, bool extCtrl = false);
	//		description:
	//			open futek loadcell and pump out raw string reading to buffer
	//			No Delay Mode
	//		parameters:
	//			dataPointsTarget:	the number of sample to be captured
	//			extCtrl:			flag to allow external ctrl for streaming mode, default is false
	//		return:
	//			t_mlError value
	bool*		startStreamingCtrl();
	//		description:
	//			flag pointer for streaming control externally
	//		return:
	//			boolean type pointer. NULL return mean no external control allowed
	t_mlError	getForceDataFromRaw(float *pDataBuff, uint32_t *pDataCount);
	//		description:
	//			convert raw buffer string and returns the data counts
	//		parameter:
	//			pDataBuff		[out]	the data buffer (float)
	//			pDataCount		[in]	the read buffer size (in sizeof(float))
	//							[out]	the read data count
	//		return
	//			t_mlError value
	float		forceLatestFromRaw();
	bool		isRunning();
	//		description:
	//			check if the loadCell is still running
	//		return:
	//			flag to the status of loadCell
	
	t_mlError	Open(uint32_t dataPointsTarget, double waitTimeout = 5.0, bool* pWaitForStart = NULL);
	//		description: 
	//			open futek loadcell and pump out the force reading
	//		parameter:
	//			dataPointsTarget:	the number of sample to be captured
	//		return:
	//			t_mlError value
	void		Close();
	//		description: 
	//			close serial port
	float		forceLatest();
	//		description:
	//			returns the latest sensor reading
	//		return:
	//			NA:		when there's error (thread not running, port re-opening, etc.)
	//			non-NA:	force reading
	uint32_t	forceDataCount();
	//		description:
	//			returns the data size in the fifo 
	//		return:
	//			zero:		no data, or dataPointsTarget == 0 at "Open"
	//			non_zero:	the data recorded in the fifo
	t_mlError	getForceData(float *pDataBuff, uint32_t *pDataCount, uint32_t* pDiscardCount = NULL);
	//		description:
	//			returns the data counts in the fifo
	//		parameter:
	//			pDataBuff		[out]	the data buffer (float)
	//			pDataCount		[in]	the read buffer size (in sizeof(float))
	//							[out]	the read data count
	//			pDiscardCount	[out, optional]	the count of discarded samples, can be NULL
	//		return
	//			t_mlError value
	bool*		dataValidFlag();
	double		getStartTime();
public:
	static CML_futekLoadCell* create(CML_usbDev* pUsbDev);
	//		[STATIC HELPER FUNCTION]
	//		description:
	//			create CML_futekLoadCell object from bsdPathName
	//		parameter:	
	//			pUsbDev:	[in]	usb device
	//		return:
	//			the pointer to the new CML_futekLoadCell object
	//		note:
	//			baudRate	115200
	//			format		k_mlSerialPortFormat_8N1;
	void lp();
	void lpStreaming();
};

#endif//defined(__cplusplus)
#endif//!TARGET_OS_IPHONE
#endif//TARGET_OS_MAC
#endif//ifndef _ML_FUTEK_LOAD_CELL_H_
