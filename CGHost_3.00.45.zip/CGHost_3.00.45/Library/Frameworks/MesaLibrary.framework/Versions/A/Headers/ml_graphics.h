//
//  ml_graphics.h
//
//  Created by Joon Kwon on 8/27/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_GRAPHICS_H_
#define _ML_GRAPHICS_H_
#include "ml_utils.h"

#if !TARGET_OS_IPHONE

#if defined(__cplusplus)
extern "C" {
#endif
	
#pragma mark -
#pragma mark Graphics Helper Function
	CGFloat	mlGrph_getTextWidth(CGContextRef ctxt, const char* const str);
	typedef enum {
		k_mlTextAlignCenter = 0,
		k_mlTextAlignLeft,
		k_mlTextAlignRight,
		k_mlTextAlignVerticalCenter,
	} t_mlTextAlign;
	void mlGrph_drawText(CGContextRef ctxt, char* str, CGFloat x, CGFloat y, t_mlTextAlign align);
	void mlGrph_drawLine(CGContextRef ctxt, double x0, double y0, double x1, double y1);
	void mlGrph_drawCircle(CGContextRef ctxt, double x0, double y0, double r);
	void mlGrph_drawRectangle(CGContextRef ctxt, double x0, double y0, double w, double h);
	double mlGrph_calculateTickStep(double bound_low, double bound_high, int tickCountMin, double* pTickPos);
#if defined(__cplusplus)
}
#endif

#endif//#if !TARGET_OS_IPHON
#endif//ifndef _ML_GRAPHICS_H_
