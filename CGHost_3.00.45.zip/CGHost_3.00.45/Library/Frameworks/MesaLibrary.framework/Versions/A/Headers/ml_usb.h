//
//  ml_usb.h
//
//  Created by Joon Kwon on 2/23/15.
//  Copyright (c) 2015 APPLE. All rights reserved.
//

#ifndef _ML_USB_H_
#define _ML_USB_H_
#if defined(__cplusplus)

#include <IOKit/IOCFPlugIn.h>//corrected from 'IOKit/IOCFPlugin.h' (build system is case sensitive)
#include <IOKit/usb/IOUSBLib.h>
#include <vector>
#include <string>
#include <mutex>
#include "ml_typedef.h"

static inline uint8_t mlUsb_getPortIndex(uint32_t locationId, uint8_t tier = 0){
	//	this function returns the usb device index on a port
	//	the index is zero-based and starting with 0 
	//	i.e. the PortIndex of the device connected to the port#1 of a hub becomes ZERO
	do{if(locationId&0xF)break;} while(locationId>>=4);
	return locationId!=0?((locationId>>(tier*4))&0xF)-1:0xFF;
}

#pragma mark -
#pragma mark [ML USB DEFINITIONS & UTILS]
/***************************************************************************************************
 *	ML USB DEFINITIONS & UTILS
 */
typedef struct t_mlUsbDevInfo{
	io_object_t		ioObject;
	std::string		devName;
	uint32_t		locationID;
	uint16_t		vndrID;
	std::string		vndrName;
	uint16_t		prodID;
	std::string		prodName;
	uint8_t			speedID;
	std::string		speedStr;
	uint8_t			protocolId;
	std::string		serialNumber;
	t_mlUsbDevInfo():ioObject(0),locationID(0),vndrID(0),prodID(0),speedID(0),protocolId(0){};
	~t_mlUsbDevInfo(){}
	bool isValid(){return !!devName.size();}
	std::string usbDevInfoStr(){
		char buff[1024];
		sprintf(buff,
				"[%s]\n"
				"ioObject:   %d\n"
				"locationID: 0x%08X\n"
				"vendor:     0x%04X [%s]\n"// %p\n"
				"product:    0x%04X [%s]\n"// %p\n"
				"speed:      0x%02X [%s]\n"// %p\n"
				"protocol:   0x%02X\n"
				"serial:     %s\n"// %p\n"
				,
				devName.c_str(),
				ioObject,
				locationID,
				vndrID,vndrName.c_str(),//vndrName.c_str(),
				prodID,prodName.c_str(),//prodName.c_str(),
				speedID,speedStr.c_str(),//speedStr.c_str(),
				protocolId,
				serialNumber.c_str()//,serialNumber.c_str()
				);
		std::string rtn = buff;
		return rtn;
	}
} t_mlUsbDevInfo, *t_mlUsbDevInfoPtr;

t_mlUsbDevInfo mlUsb_getUsbDevInfo(io_object_t ioObject);
//		description:
//			retrieve the device information of a USB device
//		parameter:
//			ioObject	the io_object of a USB device
//		return
//			t_mlError	error code

io_object_t mlUsb_getUsbDev(uint16_t vndrID, uint16_t prodID, uint8_t portIdx = 0xFF);
//		description:
//			retrieve the device information of a USB device
//		parameter:
//			vndrID		usb device vendor ID
//			prodID		usb device product ID
//		return
//			io_object_t	the IO Object ID of the device

std::vector<t_mlUsbDevInfo> mlUsb_getUsbDevList();
//		description:
//			retrieve the list of device information of USB devices attached
//		parameter:
//			none
//		return
//			list of usb device info

#pragma mark -
#pragma mark [ML USB DEVICE DETECTION]
/***************************************************************************************************
 *	ML USB DEVICE DETECTION
 */
/*	IML_usbDeviceDetectionCallback USB detection call back interface
 */
struct IML_usbDeviceDetectionCallback {
	virtual void onUsbDeviceConnected(io_object_t ioObj) = 0;
	//		description:
	//			called when the USB device is connected
	//		parameter:
	//			pUsbDev: the io_object ID of the detected device
	//		return
	//			none
};
t_mlError mlUsb_deviceDetection(uint16_t vndrId, uint16_t prodId, IML_usbDeviceDetectionCallback* callbackIntf);
//		description:
//			register usb device detection callback for USB vendor and product ID
//		parameter:
//			vndrId	USB device vendor ID
//			prodId	USB device product ID
//		return
//			kMLErr_OK for successful registration

#pragma mark -
#pragma mark [ML USB]
/*	IML_usbDeviceCallback CML_usb call back interface
 */
struct IML_usbDeviceCallback{
	virtual void onUsbDeviceDisconnected(uint32_t name, t_mlUsbDevInfo& devInfo) = 0;
	//		description:
	//			called when the USB device is disconnected
	//
	//			the callee should NOT delete the object since
	//			the object is ALREADY DELETED before the event call.
	//
	//		parameter:
	//			name:	the usb device 'name' set through setCallback function.
	//		return
	//			none
};

/***************************************************************************************************
 *	CML_usb
 */
class CML_usb : public CML_baseObject {
protected:
	io_object_t							_ioObject;
	t_mlUsbDevInfo						_devInfo;
	IOCFPlugInInterface **				_iodev;
	IOUSBDeviceInterface320**			_device;		// not to be released by application
	int									_interfaceNumber;
	IOUSBInterfaceInterface300**		_interface;
	//
	io_object_t							_noti;
	IONotificationPortRef				_notiPortRef;	// not to be released by application
	std::mutex							_mtx;
	// callback
	std::vector<uint32_t>				_name;
	std::vector<IML_usbDeviceCallback*>	_callback;
public:
	CML_usb(io_object_t ioObj);
	CML_usb(uint16_t vndrID, uint16_t prodID, uint8_t portIdx = 0xFF);
	virtual ~CML_usb();
	t_mlError setLogManager(CML_logManager* lm);
public:
	t_mlError	setCallback(uint32_t name, IML_usbDeviceCallback* callback);
	void		removeCallback(IML_usbDeviceCallback* callback);
	t_mlError	setInterfaceNumber(int interfaceNum);
protected: // subclass to use, not for public use
	t_mlError	setRequest(uint16_t reportId, void* data, size_t length);
	t_mlError	getRequest(uint16_t reportId, void* data, size_t length);
public:
	static void onUsbDevEvent(void *refCon, io_service_t service, natural_t messageType, void *messageArgument);
};

/***************************************************************************************************
 *	CML_usbDev
 *	Description:	USB device
 */

#define USBDEV_MAX_INTERFACE_NUM	8

#pragma mark -
#pragma mark CML_usbDev
struct IML_usbDevCallback{
	virtual void onUsbDevDisconnected(uint32_t name, t_mlUsbDevInfo& devInfo) = 0;
};

class CML_usbDev: public CML_baseObject {
	friend class CML_serial;
	friend class CML_ftdi;
protected:
	t_mlUsbDevInfo				_devInfo;
	//
	io_object_t					_ioObject;
	IOCFPlugInInterface **		_iodev;
	IOUSBDeviceInterface320**	_device;				// not to be released by application
	//
	IOUSBInterfaceInterface**	_interfaces[USBDEV_MAX_INTERFACE_NUM];
	int							_interfaceNumTotal;
	//
	io_object_t					_noti;
	IONotificationPortRef		_notiPortRef;	// not to be released by application
	std::mutex					_mtx;
	// callback
	uint32_t					_name;
	IML_usbDevCallback*			_callback;
public:
	CML_usbDev();
	virtual ~CML_usbDev();
	t_mlError	setLogManager(CML_logManager* lm);
	t_mlUsbDevInfo	devInfo(){return _devInfo;};
	io_object_t	ioObject(){return _ioObject;};
public:
	void		setCallback(uint32_t name, IML_usbDevCallback* callback);
//	t_mlError	setInterfaceNumber(int interfaceNum);
	t_mlError	getInterfaceNumber(uint8_t interfaceClass, uint8_t* pInterfaceNumber);
	t_mlError	getBsdPath(char* bsdPath, int maxBsdPathLeng);
public:
	t_mlError	setRequest(uint16_t reportId, void* data, uint32_t length);
	t_mlError	getRequest(uint16_t reportId, void* data, uint32_t length);
	t_mlError	setInterfaceRequest(uint8_t intfNum, uint8_t req, uint16_t reportId, void* data, uint32_t length);
	t_mlError	getInterfaceRequest(uint8_t intfNum, uint8_t req, uint16_t reportId, void* data, uint32_t length);
public:
	static CML_usbDev* create(io_object_t usbDev);
	static CML_usbDev* create(uint16_t vndrID, uint16_t prodID, uint32_t locationID=0x00000000);
	static void onUsbDevEvent(void *refCon, io_service_t service, natural_t messageType, void *messageArgument);
private:
	IOUSBDescriptorHeader* nextDescriptor(const void *desc);
	IOReturn findNextInterfaceDescriptor(const IOUSBConfigurationDescriptor *configDescIn, const IOUSBInterfaceDescriptor *intfDesc,IOUSBInterfaceDescriptor **descOut);
	const char* getUSBErrorString(IOReturn rtn);
};

/***************************************************************************************************
 *	CML_usbDevDetector
 *	Description:	USB device detector
 */
#pragma mark -
#pragma mark CML_usbDevDetector

/*	CML_usbDevDetector:	will monotir and notify when the expected USB device is connected
 */
struct IML_usbDevDetectorCallback {
	virtual void onUsbDevConnected(CML_usbDev* pUsbDev) = 0;
};

struct t_mlUsbDeviceDetector{
	int32_t vndrId;
	int32_t prodId;
	IONotificationPortRef notiPortRef;
	io_iterator_t notiIterator;
	IML_usbDevDetectorCallback* callback;
	t_mlUsbDeviceDetector():vndrId(0),prodId(0),notiPortRef(NULL),
	notiIterator(NULL),callback(NULL){};
	void clear(){
		if (notiPortRef)	{IONotificationPortDestroy(notiPortRef);notiPortRef = NULL;	}
		if (notiIterator)	{IOObjectRelease(notiIterator);			notiIterator = NULL;}
	};
};

class CML_usbDevDetector: public CML_baseObject {
	std::vector<t_mlUsbDeviceDetector> _devDetectors;
public:
	CML_usbDevDetector();
	virtual ~CML_usbDevDetector();
	t_mlError setLogManager(CML_logManager* lm);
	t_mlError monitor(uint16_t vndrId, uint16_t prodId, IML_usbDevDetectorCallback* callback);
	static void onUsbDevDetected(void *refCon, io_iterator_t iterator);
};

#endif//defined(__cplusplus)
#endif//ifndef _ML_USB_H_
