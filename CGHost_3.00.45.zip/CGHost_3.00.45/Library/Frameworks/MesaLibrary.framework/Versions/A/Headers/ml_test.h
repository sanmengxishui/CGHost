//
//  ml_test.h
//
//  Created by Joon Kwon on 9/15/15.
//  Copyright (c) 2015 Joon Kwon. All rights reserved.
//

#ifndef _ML_TEST_H_
#define _ML_TEST_H_

#if defined(__cplusplus)
#include <ml_utils.h>
#include <ml_mtcp.h>
#include <unordered_map>
#include <vector>
#include <string>
#include <thread>
#include <mutex>

#pragma mark -
#pragma mark [TEST SCRIPT]
/*--------------------------------------------------------------------------------------------------
 *	[TEST SCRIPT]
 */

//	test type
typedef enum {
	kMlTestType_unknown = 0,
	kMlTestType_setup,		// cannot COF
	kMlTestType_test,
	kMlTestType_wrapup,		// no skip
	//
	kMlTestType_MAX,
} t_mlTestType;

static const std::vector<std::string> kMlScriptMarkerStr = {
	"unknown",// unknown
	"[*** TestSetup ***]",
	"[*** Test&Cal ***]",
	"[*** TestEnd ***]",
};

static const std::vector<std::string> kMlTestTypeStr = {
	" unknown ",
	" setup   ",
	" test&cal",
	" wrap-up ",
};

static const std::string kMLTestClassMark =			"class=";
static const std::string kMLTestAsyncMark =			"async";
static const std::string kMLTestPrerequisiteMark=	"waitFor=";

struct IML_testItem {
	t_mlTestType				testType;
	std::string					testName;
	std::string					className;
	std::vector<std::string>	prerequisites;
	bool						doAsync;
	std::vector<std::string>	args;
	//
	IML_testItem():testType(kMlTestType_unknown),doAsync(false){};
	~IML_testItem(){};
}  __attribute__((packed));
t_mlError mlTest_loadTestScript(std::string fileName, std::vector<IML_testItem>& items);

#pragma mark -
#pragma mark [TEST DATA CLASS]
/*--------------------------------------------------------------------------------------------------
 *	[TEST DATA CLASS]
 */
//	test data type
typedef enum {
	kMlReportType_none = 0,
	kMlReportType_param,
	kMlReportType_attribute,
	//
	kMlReportType_MAX,
} t_mlReportType;

static const std::vector<std::string> kMlReportTypeStr = {
	"none",
	"param",
	"attribute",
	//
};

static const std::vector<std::string> kMlDataTypeStr = {
	"float",
	"double",
	"int8_t",
	"int16_t",
	"int32_t",
	"int64_t",
	"uint8_t",
	"uint16_t",
	"uint32_t",
	"uint64_t",
	"string",
};

struct t_mlTestData {
	// sepc info
	std::string		testName;
	std::string		fomName;
	std::string		typeStr;
	std::string		unitStr;
	double			LSL, USL;
	//
	t_mlReportType	report_type;
	//
	double			value;
	std::string		str;
	//
	t_mlTestData():LSL(NAN),USL(NAN),report_type(kMlReportType_none),value(NAN){};
	bool isParametric() {return report_type==kMlReportType_param;};
	bool isPass(){ return (!isParametric()
						   || (!_IS_VALID_NUMBER_(LSL) && !_IS_VALID_NUMBER_(USL))
						   || (_IS_VALID_NUMBER_(value)
							   && (!_IS_VALID_NUMBER_(LSL)||LSL<=value)
							   && (!_IS_VALID_NUMBER_(USL)||value<=USL)
							   )
						   );}
	void reset() { value = NAN; str.clear(); str.shrink_to_fit();};
};

class CML_testData: public CML_baseObject {
private:
	std::unordered_map<std::string, size_t> _testDataHTable;
	std::vector<t_mlTestData>	_testDataTable;
	long						_testNameLengMax;
	long						_fomNameLengMax;
	std::string					_errString;
	std::string					_strTime_start;
	std::string					_strTime_end;
	double						_time_start;
	double						_test_time;
	t_mlTestData* getDataEntry(std::string& testName, std::string& fomName);
	std::vector<uint32_t>		_err_code;
	std::vector<std::string>	_err_string;
	//
	std::string					_spec_versoin;
public:
	CML_testData();
	virtual ~CML_testData();
	t_mlError setLogManager(CML_logManager* lm);
	void reset();	// reset value and string value, test limits not to be cleared
public:
	void markTestStart();
	void markTestEnd();
public:
	t_mlError	addDataSymbol(std::string	testName,
							  std::string	fomName,
							  std::string	typeStr,
							  double		LSL,
							  double		USL,
							  std::string	unitStr,
							  bool			isAttribute);
	void		print_symbol_table(std::string title = "", FILE* fp = stdout, const char delimiter='\t');
	double		get_LSL(std::string& testName, std::string fomName);
	double		get_USL(std::string& testName, std::string fomName);
	t_mlError	overrideSpec(std::string&	testName,
							 std::string	fomName,
							 double			LSL,
							 double			USL);
	t_mlError	overrideSpec(std::string fn);
	//
	t_mlError	recordData(std::string& testName, std::string fomName, double value);
	t_mlError	recordData(std::string& testName, std::string fomName, std::string str);
	void		recordError(uint32_t errCode, std::string errString);
	//
	double		getData(std::string& testName, std::string fomName, bool noNanReturn = true);
	// getData option noNanReturn
	// As sanity check for any calculation, getData should not return Nan in most of cases
	// As binary case 0 or 1, Nan is still a valid output
	std::string	getString(std::string& testName, std::string fomName);
	std::string getDataType(std::string& testName, std::string fomName);
	std::string getDataUnit(std::string& testName, std::string fomName);
	t_mlReportType getDataReportType(std::string& testName, std::string fomName);

	size_t							getErrCount()	{return _err_code.size();	};
	const std::vector<uint32_t>&	getErrCodes()	{return _err_code;			};
	const std::vector<std::string>&	getErrStrings()	{return _err_string;		};
	//
	t_mlError	checkSpec(std::string& testName, std::string fomName, const char* format);
	//
	const size_t getTestDataCount() {return _testDataTable.size();};
	std::string	 getTestName(size_t testDataIndex){return _testDataTable[testDataIndex].testName;};
	std::string	 getFomName(size_t testDataIndex){return _testDataTable[testDataIndex].fomName;};
public:
	void		overwrite_for_summary_csv(double time_start, double test_time);
	t_mlError	get_statistics_csv(std::string	fileName,
								   std::string	serialNumber,
								   std::string	tester_id,
								   std::string	config,
								   std::string	title,	// may include version with prefix "sw_version:"
								   bool			include_failing_items_column,
								   int			include_failing_items_column_num = -1, // negative means unlimited
								   bool			showNANValue = true);
	t_mlError	add_to_summary_csv(std::string	fileName,
								   std::string	serialNumber,
								   std::string	tester_id,
								   std::string	config,
								   std::string	title,	// may include version with prefix "sw_version:"
								   bool			include_failing_items_column,
								   int			include_failing_items_column_num = -1, // negative means unlimited
								   bool			showNANValue = true);
};

#pragma mark -
#pragma mark [TEST STATUS DEFINITION]
/*--------------------------------------------------------------------------------------------------
 *	[TEST STATUS DEFINITION]
 */
//	test status
typedef enum {
	kMlTestStat_NA = 0,		// indicates the test is not executed yet
	kMlTestStat_aborted,	// test aborted,
	kMlTestStat_standby,	// waiting for prerequisites
	kMlTestStat_running,	// currently testing
	kMlTestStat_pass,		// test passed
	kMlTestStat_fail,		// test failed
	kMlTestStat_cof,		// test failed, but COF
	//
	kMlTestStat_MAX,
} t_mlTestStat;

static const std::vector<std::string> kMlTestStatStr = {
	"NA",
	"ABORTED",
	"STANDBY",
	"TESTING",
	"PASS",
	"FAIL",
	"COF",
};

#pragma mark -
//	test excecution mode
typedef enum {
	kMlTestMode_PROD = 0,
	kMlTestMode_COF,
	//
	kMlTestMode_MAX,
	kMlTestMode_unknown = kMlTestMode_MAX,
} t_mlTestMode;

static const std::vector<std::string> kMlTestModeStr = {
	"PROD",
	"COF",
	"unknown",
};

#pragma mark -
#pragma mark [TEST ITEM BASE CLASS]
/*--------------------------------------------------------------------------------------------------
 *	[TEST ITEM BASE CLASS, CML_testItem]
 */
struct IML_testItem_callback {
	virtual void onStatusUpdated(long testItemIndex) = 0;
};

class CML_testItem: public CML_baseObject {
	friend class CML_testSession;
protected:
	long						_testItemIdx;
	//	set per test script
	t_mlTestType				_testType;
	std::string					_testName;
	std::vector<std::string>	_prerequisites;
	bool						_doAsync;
	std::vector<std::string>	_args;
	//
	std::mutex					_mtxStatus;
	//	set by CML_testSession
	std::string					_sn;
	std::string					_logPathRoot;
	double						_total_test_t0;
private:
	volatile t_mlTestStat		_status;
	std::vector<IML_testItem_callback*> _callback;
	//
	dispatch_queue_t			_queueStat;
protected:
	const std::vector<CML_testItem*>* _pTestItemList;
	CML_testData* _pTestData;
public:
	/*	constructor, destructor
	 */
	CML_testItem();
	virtual ~CML_testItem();
	t_mlError setLogManager(CML_logManager* lm);
	//
	void setItemInfo(const IML_testItem& info, std::string& sn, std::string& logPathRoot, const std::vector<CML_testItem*>* pItemList);
	//
	t_mlTestType					testType()		{return _testType;};
	const std::string&				testTypeStr()	{return kMlTestTypeStr[_testType];};
	const std::string&				testName()		{return _testName;}
	const std::vector<std::string>& testArgs()		{return _args;};
	t_mlTestStat					testStatus();
	const std::string&				testStatusStr()	{return kMlTestStatStr[_status];};
	//
	virtual void					registerDataSymbol()				= 0;
	virtual void					performTest(t_mlTestMode testMode)	= 0;
	virtual void					abortTest()							= 0;
	virtual void					handle_mtcp_packet(const tMTCP_header* pHdr, const uint8_t* payload) = 0;
	/*	callback
	 */
	void setCallback(IML_testItem_callback* callback);
	void removeCallback(IML_testItem_callback* callback);
	void setStatus(t_mlTestStat newStat);	//	will update the status and post status
protected:
	bool	waitForCompletion(double timeoutMs=10.0f);
	bool	waitPrerequisite();
};

#pragma mark -
#pragma mark [TEST ITEM CLASS REGISTRATION]
/*--------------------------------------------------------------------------------------------------
 *	TEST ITEM CLASS REGISTRATION
 */
#define REGISTER_TEST_CLASS(cls) \
	static CML_testItem* cls##_create(){return new cls;}\
	__attribute__((constructor)) static void cls##_registerTestClass(){mlTest_registerTestClass(#cls,cls##_create);}
void mlTest_registerTestClass(std::string className, CML_testItem*(*classCreator)());
void mlTest_showTestClassTable(CML_logManager* lm);
bool mlTest_isTestClassContructorAvailable(std::string className);
CML_testItem* mlTest_createTestClassInstance(std::string className);

#pragma mark -
#pragma mark [TEST DATA SYMBOL REGISTRATION]
/*--------------------------------------------------------------------------------------------------
 *	TEST DATA SYMBOL REGISTRATION
 */
#define ML_ADD_DATA_SYMBOL_BEGIN \
/**/CML_testData& ___tdl___ = *_pTestData;\
/**/{
#define ML_ADD_DATA_SYMBOL(fomName,type,LSL,USL,unitStr,isAttribute)\
/**/___tdl___.addDataSymbol(_testName,fomName,ML_GET_TYPE_STR(type),LSL,USL,unitStr,isAttribute);
#define ML_ADD_DATA_SYMBOL_END\
/**/}

#pragma mark -
#pragma mark [TEST SESSION CLASS]
/*--------------------------------------------------------------------------------------------------
 *	TEST SESSION CLASS
 */

struct IML_testSession_callback {
	virtual void onTestBegin(long testSessionIndex) = 0;
	virtual void onTestEnd(long testSessionIndex) = 0;
	virtual void onStatusUpdated(long testSessionIndex, long testItemIndex) = 0;
	virtual void onLogStrUpdated(long testSessionIndex, const char* str) = 0;
};

class CML_testSession: public CML_mtcp, public IML_testItem_callback, public IML_logRelay, public IML_mtcpCallback{
protected:
	long						_testSssnIdx;
	std::string					_serialNumber;
	std::string					_logPathRoot;
	std::vector<CML_testItem*>	_testItems;
	CML_testData				_testData;
	//
	CML_logManager*				_lm;
	std::vector<IML_testSession_callback*> _callback;
	// spec holder
	// GUI
	std::string					_guiMsg;
private:
	double						_time_test_t0;
	std::thread					_thread;
	volatile bool				_isThreadRunning;
	//
	t_mlTestMode				_testMode;
public:
	/*	constructor, destructor
	 */
	CML_testSession(long testSessionIdx, std::string logPathRoot, std::string scriptFileName);
	virtual ~CML_testSession();
	t_mlError setLogManager(CML_logManager* lm);
	/*	setup
	 */
	t_mlError setupTestSession(std::string sn);
	/*  reset
	 */
	void resetTestSession();
	//
	void setSerialNumber(std::string sn);
	const std::string& serialNumber(){ return _serialNumber;};
	t_mlTestStat getStatus();
	double test_start_time(){return _time_test_t0;};
	//
	/*	callback
	 */
	void setCallback(IML_testSession_callback* callback);
	void removeCallback(IML_testSession_callback* callback);
	const std::vector<CML_testItem*>& testItems(){return _testItems;};
	//	IML_testItem_callback
	void onStatusUpdated(long testItemIndex);	// callback from CML_testItem class instance
	//	IML_logRelay
	void onLogRelay(const char* strRelay);	// callback from CML_logManager class instance
	/*	test - manual mode
	 */
	virtual bool isReadyToTest(std::string& errString) = 0;
	bool isRunning(){return _isThreadRunning;};
	t_mlError performTest(t_mlTestMode testMode = kMlTestMode_PROD);
	void abortTest();
	void sendStatusUpdateNotification(long testItemIndex);
	/*	test - MTCP mode
	 */
	bool isMtcpRunning();
	t_mlError setSocket	(int skt, CML_logManager* lm, t_mlVbsLvl vl = kVL1);
	virtual void processMtcpPacket(const tMTCP_header* pHeader, const uint8_t* payload) = 0;
	//	IML_mtcpCallback
	void onMtcpConnect	(uint32_t sktName);
	void onMtcpReceive	(uint32_t sktName, const tMTCP_packet* pPacket);
	void onMtcpClose	(uint32_t sktName);
	/*  GUI - view
	 */
	void setGUIMessage(const std::string message) {_guiMsg = message;};
	std::string& guiMessage(){return _guiMsg;};
private:
	void testProc();
};

#endif//defined(__cplusplus)
#endif//ifndef _ML_TEST_H_
