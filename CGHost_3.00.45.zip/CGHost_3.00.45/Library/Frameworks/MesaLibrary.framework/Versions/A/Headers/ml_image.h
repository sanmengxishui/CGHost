//
//  ml_image.h
//
//  Created by Joon Kwon on 8/27/14.
//  Copyright (c) 2014 Joon Kwon. All rights reserved.
//

#ifndef _ML_IMAGE_H_
#define _ML_IMAGE_H_
#include <ml_typedef.h>
#include <ml_error.h>
#include <ml_log.h>
#include <ml_math.h>

#if defined(__cplusplus)
extern "C" {
#endif
	
	/*	 sensor image data manupulation	------------------------------------------------------------
	 */
#	pragma mark -
#	pragma mark sensor image data manupulation
	// vertical image flip
	void	mlImg_flipUInt8_Vertical(UInt8*  data, int width, int height)		__attribute__((deprecated("Please Use mlImg_flip_vertical(...) function")));
	void	mlImg_flipSInt8_Vertical(SInt8*  data, int width, int height)		__attribute__((deprecated("Please Use mlImg_flip_vertical(...) function")));
	void	mlImg_flipUInt16_Vertical(UInt16* data, int width, int height)		__attribute__((deprecated("Please Use mlImg_flip_vertical(...) function")));
	void	mlImg_flipSInt16_Vertical(SInt16* data, int width, int height)		__attribute__((deprecated("Please Use mlImg_flip_vertical(...) function")));
	void	mlImg_flipUInt32_Vertical(UInt32* data, int width, int height)		__attribute__((deprecated("Please Use mlImg_flip_vertical(...) function")));
	void	mlImg_flipSInt32_Vertical(SInt32* data, int width, int height)		__attribute__((deprecated("Please Use mlImg_flip_vertical(...) function")));
	void	mlImg_flipFloat_Vertical(float*  data, int width, int height)		__attribute__((deprecated("Please Use mlImg_flip_vertical(...) function")));
	void	mlImg_flipDouble_Vertical(double* data, int width, int height)		__attribute__((deprecated("Please Use mlImg_flip_vertical(...) function")));
	// horizontal image flip
	void	mlImg_flipUInt8_Horizontal(UInt8*  data, int width, int height)		__attribute__((deprecated("Please Use mlImg_flip_horizontal(...) function")));
	void	mlImg_flipSInt8_Horizontal(SInt8*  data, int width, int height)		__attribute__((deprecated("Please Use mlImg_flip_horizontal(...) function")));
	void	mlImg_flipUInt16_Horizontal(UInt16* data, int width, int height)	__attribute__((deprecated("Please Use mlImg_flip_horizontal(...) function")));
	void	mlImg_flipSInt16_Horizontal(SInt16* data, int width, int height)	__attribute__((deprecated("Please Use mlImg_flip_horizontal(...) function")));
	void	mlImg_flipUInt32_Horizontal(UInt32* data, int width, int height)	__attribute__((deprecated("Please Use mlImg_flip_horizontal(...) function")));
	void	mlImg_flipSInt32_Horizontal(SInt32* data, int width, int height)	__attribute__((deprecated("Please Use mlImg_flip_horizontal(...) function")));
	void	mlImg_flipFloat_Horizontal(float*  data, int width, int height)		__attribute__((deprecated("Please Use mlImg_flip_horizontal(...) function")));
	void	mlImg_flipDouble_Horizontal(double* data, int width, int height)	__attribute__((deprecated("Please Use mlImg_flip_horizontal(...) function")));
	// image crop
	void	mlImg_cropImageUInt8(UInt8*  data, int width, int height, int x, int y, int newWidth, int newHeight)	__attribute__((deprecated("Please Use mlImg_crop(...) function")));
	void	mlImg_cropImageSInt8(SInt8*  data, int width, int height, int x, int y, int newWidth, int newHeight)	__attribute__((deprecated("Please Use mlImg_crop(...) function")));
	void	mlImg_cropImageUInt16(UInt16* data, int width, int height, int x, int y, int newWidth, int newHeight)	__attribute__((deprecated("Please Use mlImg_crop(...) function")));
	void	mlImg_cropImageSInt16(SInt16* data, int width, int height, int x, int y, int newWidth, int newHeight)	__attribute__((deprecated("Please Use mlImg_crop(...) function")));
	void	mlImg_cropImageUInt32(UInt32* data, int width, int height, int x, int y, int newWidth, int newHeight)	__attribute__((deprecated("Please Use mlImg_crop(...) function")));
	void	mlImg_cropImageSInt32(SInt32* data, int width, int height, int x, int y, int newWidth, int newHeight)	__attribute__((deprecated("Please Use mlImg_crop(...) function")));
	void	mlImg_cropImageFloat(float*  data, int width, int height, int x, int y, int newWidth, int newHeight)	__attribute__((deprecated("Please Use mlImg_crop(...) function")));
	void	mlImg_cropImageDouble(double* data, int width, int height, int x, int y, int newWidth, int newHeight)	__attribute__((deprecated("Please Use mlImg_crop(...) function")));
	
#if defined(__cplusplus)
}
#endif

#if !TARGET_OS_IPHONE
#if defined(__cplusplus)

#	pragma mark -
#	pragma mark image export
/*--------------------------------------------------------------------------------------------------
 *	image image export
 */
	void mlImg_exportSensorImage(char* fileName, float* imgData, int width, int height, char* infoStr, uint8_t stdevLimit);
	void mlImg_exportSensorImage(char* fileName, double* imgData, int width, int height, char* infoStr, uint8_t stdevLimit);

	t_mlError mlImg_exportLineCurve(CML_logManager* lm,const char* fileName,double* data,int dataCnt,int imgWidth,int imgHeight,char* infoStr);
	t_mlError mlImg_exportLineCurve(CML_logManager* lm, const char* fileName,float* data,int dataCnt,int imgWidth,int imgHeight,char* infoStr);

	t_mlError mlImg_exportImage(CML_logManager* lm, const char* fileName, const float* imgData, const int width, const int height, const char* infoStr, const UInt8 stdevLimit, const bool doScaling, double maxBound, double minBound);
	t_mlError mlImg_exportImage(CML_logManager* lm, const char* fileName, const double*imgData, const int width, const int height, const char* infoStr, const UInt8 stdevLimit, const bool doScaling, double maxBound, double minBound);

#	pragma mark -
#	pragma mark image flip/crop
/*--------------------------------------------------------------------------------------------------
 *	image flip/crop
 */
template <typename T>	void mlImg_flip_vertical(T* data, size_t w, size_t h){
	if (!data || w<1 || h<1) assert(0);
	size_t line_buff_sz = w*sizeof(T); T* buff = (T*)malloc(line_buff_sz); assert(buff);
	for (int r=0;r<(h/2);r++){memcpy(buff,data+r*w,line_buff_sz);memcpy(data+r*w,data+(h-1-r)*w,line_buff_sz);memcpy(data+(h-1-r)*w,buff,line_buff_sz);}
	FREE_MEM(buff);}

template <typename T>	void mlImg_flip_horizontal(T* data, size_t w, size_t h){
	if (!data || w<1 || h<1) assert(0);
	for (int r=0;r<h;r++) for (int c=0;c<w/2;c++) {T tmp = data[r*w+c]; data[r*w+c]=data[r*w+w-1-c]; data[r*w+w-1-c]=tmp;}}

template <typename T>	void mlImg_crop(T* data, size_t w, size_t h, size_t x, size_t y, size_t n_w, size_t n_h){
	if (!data || w<1 || h<1
		|| x<0 || y<0 || n_w<1 || n_h<1
		|| w<x || h<y || w<(x+n_w) || h<(y+n_h)) assert(0);
	T* dst = data;
	for (size_t r=y;r<(y+n_h);r++) for (size_t c=x;c<(x+n_w);c++){*dst = data[r*w+c];dst++;}}

#	pragma mark -
#	pragma mark BMP file
/*--------------------------------------------------------------------------------------------------
 *	BMP file
 */
struct t_mlBmpHeader{
	uint16_t	magic;			// 'BM'
	uint32_t	file_size;		// ** file size
	uint16_t	rsvd1;
	uint16_t	rsvd2;
	uint32_t	data_offset;	// ** need to keep the content (palette)
	t_mlBmpHeader():magic(0),file_size(0),rsvd1(0),rsvd2(0),data_offset(0){};
	void print(){
		printf("- bmp header (%ld bytes) -\n",sizeof(t_mlBmpHeader));
		printf("\tmagic            = '%c%c' 0x%04X\n",magic&0xFF,(magic>>8)&0xFF,magic);
		printf("\t* file_size      = %d\n",file_size);
		printf("\trsvd1            = %d\n",rsvd1);
		printf("\trsvd2            = %d\n",rsvd2);
		printf("\tdata_offset      = %d\n",data_offset);
	}
} __attribute__((packed));

struct t_mlBmpInfoHeader{
	uint32_t	info_header_size;
	int32_t		width;			// ** image width
	int32_t		height;			// ** image height
	uint16_t	planes;
	uint16_t	bits_per_pixel;
	uint32_t	compression;	// 0:no, 1:RLE8, 2:RLE4, , 3:RGB bitmap w/ mask
	uint32_t	image_size;		// ** needs to be update
	int32_t		resolution_x;
	int32_t		resolution_y;
	uint32_t	ncolors;
	uint32_t	important_colors;
	t_mlBmpInfoHeader():info_header_size(0),width(0),height(0),planes(0),bits_per_pixel(0),compression(0),image_size(0),resolution_x(0),resolution_y(0),ncolors(0),important_colors(0){};
	void print(){
		printf("- bmp info header (%ld bytes) -\n",sizeof(t_mlBmpInfoHeader));
		printf("\thdr size         = %d\n",info_header_size);
		printf("\t* width          = %d\n",width);
		printf("\t* height         = %d\n",height);
		printf("\tplanes           = %d\n",planes);
		printf("\tbits_per_pixel   = %d\n",bits_per_pixel);
		printf("\tcompression      = %d\n",compression);
		printf("\t* image_size     = %d\n",image_size);
		printf("\tresolution_x     = %d\n",resolution_x);
		printf("\tresolution_y     = %d\n",resolution_y);
		printf("\tncolors          = %d\n",ncolors);
		printf("\timportant_colors = %d\n",important_colors);
	}
} __attribute__((packed));

t_mlData_2d<uint8_t> mlImg_load_bmp_8bpp(string fn);
t_mlError mlImg_save_bmp_8bpp(string fn, const uint8_t* img, size_t width, size_t height);
template <typename T>
t_mlError mlImg_save_bmp_8bpp(string fn, t_mlData_2d<T>& dat){
	t_mlData_2d<uint8_t> image; image = dat;
	return mlImg_save_bmp_8bpp(fn, image.data(), image.w, image.h);
}

class CML_bmp_8bpp{
	std::vector<uint8_t>	_raw_data;
public:
	t_mlBmpHeader*			pBmp_hdr;
	t_mlBmpInfoHeader*		pInf_hdr;
	uint8_t*				pPalette;
	uint8_t*				pImg_data;
public:
	CML_bmp_8bpp():_raw_data(NULL),pBmp_hdr(NULL),pInf_hdr(NULL),pPalette(NULL),pImg_data(NULL){};
	CML_bmp_8bpp(std::string fn);
	~CML_bmp_8bpp(){};
	/* basic functions
	 */
	t_mlError load(std::string fn);	// load bmp file
	bool isValid(){return pBmp_hdr!=NULL && pInf_hdr!=NULL && pImg_data!=NULL;};
	size_t width(){return isValid()?pInf_hdr->width:0;};
	size_t height(){return isValid()?pInf_hdr->height:0;};
	/* statistics
	 */
	uint8_t max(){	return isValid()?mlMath_max		(pImg_data,pInf_hdr->width*pInf_hdr->height):	NA;	};
	uint8_t min(){	return isValid()?mlMath_min		(pImg_data,pInf_hdr->width*pInf_hdr->height):	NA;	};
	float avg(){	return isValid()?mlMath_avg		(pImg_data,pInf_hdr->width*pInf_hdr->height):	NA;	};
	float med(){	return isValid()?mlMath_median	(pImg_data,pInf_hdr->width*pInf_hdr->height):	NA;	};
	float stdev(){	return isValid()?mlMath_stdev	(pImg_data,pInf_hdr->width*pInf_hdr->height):	NA;	};
	/* utils / debug tools
	 */
	void save(std::string fn);
	void print_header(bool print_palette = false);
	std::vector<uint32_t> luminance_histogram();
	void print_luminance_histogram();
public:
	/* static functions
	 */
	static t_mlError save(std::string fn, const uint8_t* img, size_t width, size_t height);
};

#	pragma mark -
#	pragma mark TIFF file
/*--------------------------------------------------------------------------------------------------
 *	TIFF file
 */

enum t_mlTiffTag{
	NewSubfileType		= 254,
	SubfileType			= 255,
	ImageWidth			= 256,
	ImageLength			= 257,
	BitsPerSample		= 258,
	Compression			= 259,
	PhotometricInterpretation		= 262,
	Threshholding		= 263,
	CellWidth			= 264,
	CellLength			= 265,
	FillOrder			= 266,
	DocumentName		= 269,
	ImageDescription	= 270,
	Make				= 271,
	Model				= 272,
	StripOffsets		= 273,
	Orientation			= 274,
	SamplesPerPixel		= 277,
	RowsPerStrip		= 278,
	StripByteCounts		= 279,
	MinSampleValue		= 280,
	MaxSampleValue		= 281,
	XResolution			= 282,
	YResolution			= 283,
	PlanarConfiguration = 284,
	PageName			= 285,
	XPosition			= 286,
	YPosition			= 287,
	FreeOffsets			= 288,
	FreeByteCounts		= 289,
	GrayResponseUnit	= 290,
	GrayResponseCurve	= 291,
	T4Options			= 292,
	T6Options			= 293,
	ResolutionUnit		= 296,
	PageNumber			= 297,
	TransferFunction	= 301,
	Software			= 305,
	DateTime			= 306,
	Artist				= 315,
	HostComputer		= 316,
	Predictor			= 317,
	WhitePoint			= 318,
	PrimaryChromaticities = 319,
	ColorMap			= 320,
	HalftoneHints		= 321,
	
	TileWidth			= 322,
	TileLength			= 323,
	TileOffsets			= 324,
	TileByteCounts		= 325,
	InkSet				= 332,
	InkNames			= 333,
	NumberOfInks		= 334,
	DotRange			= 336,
	TargetPrinter		= 337,
	ExtraSamples		= 338,
	SampleFormat		= 339,
	SMinSampleValue		= 340,
	SMaxSampleValue		= 341,
	TransferRange		= 342,
	JPEGProc			= 512,
	JPEGInterchangeFormat = 513,
	JPEGInterchangeFormatLngth = 514,
	JPEGRestartInterval = 515,
	JPEGLosslessPredictors = 517,
	JPEGPointTransforms = 518,
	JPEGQTables			= 519,
	JPEGDCTables		= 520,
	JPEGACTables		= 521,
	YCbCrCoefficients	= 529,
	YCbCrSubSampling	= 530,
	YCbCrPositioning	= 531,
	ReferenceBlackWhite = 532,
	Copyright			= 33432,
};

static inline const char* ml_getTiffFdTagStr(uint16_t tag){
	const char* rtn = "unknown";
	switch (tag) {
		case Artist:				{rtn = "Artist"; break;}
		case BitsPerSample:			{rtn = "BitsPerSample"; break;}
		case CellLength:			{rtn = "CellLength"; break;}
		case CellWidth:				{rtn = "CellWidth"; break;}
		case ColorMap:				{rtn = "ColorMap"; break;}
		case Compression:			{rtn = "Compression"; break;}
		case Copyright:				{rtn = "Copyright"; break;}
		case DateTime:				{rtn = "DateTime"; break;}
		case ExtraSamples:			{rtn = "ExtraSamples"; break;}
		case FillOrder:				{rtn = "FillOrder"; break;}
		case FreeByteCounts:		{rtn = "FreeByteCounts"; break;}
		case FreeOffsets:			{rtn = "FreeOffsets"; break;}
		case GrayResponseCurve:		{rtn = "GrayResponseCurve"; break;}
		case GrayResponseUnit:		{rtn = "GrayResponseUnit"; break;}
		case HostComputer:			{rtn = "HostComputer"; break;}
		case ImageDescription:		{rtn = "ImageDescription"; break;}
		case ImageLength:			{rtn = "ImageLength"; break;}
		case ImageWidth:			{rtn = "ImageWidth"; break;}
		case Make:					{rtn = "Make"; break;}
		case MaxSampleValue:		{rtn = "MaxSampleValue"; break;}
		case MinSampleValue:		{rtn = "MinSampleValue"; break;}
		case Model:					{rtn = "Model"; break;}
		case NewSubfileType:		{rtn = "NewSubfileType"; break;}
		case Orientation:			{rtn = "Orientation"; break;}
		case PhotometricInterpretation:{rtn = "PhotometricInterpretation"; break;}
		case PlanarConfiguration:	{rtn = "PlanarConfiguration"; break;}
		case ResolutionUnit:		{rtn = "ResolutionUnit"; break;}
		case RowsPerStrip:			{rtn = "RowsPerStrip"; break;}
		case SamplesPerPixel:		{rtn = "SamplesPerPixel"; break;}
		case Software:				{rtn = "Software"; break;}
		case StripByteCounts:		{rtn = "StripByteCounts"; break;}
		case StripOffsets:			{rtn = "StripOffsets"; break;}
		case SubfileType:			{rtn = "SubfileType"; break;}
		case Threshholding:			{rtn = "Threshholding"; break;}
		case XResolution:			{rtn = "XResolution"; break;}
		case YResolution:			{rtn = "YResolution"; break;}
			// TIFF Extension
		case SampleFormat:			{rtn = "SampleFormat"; break;};
		case SMinSampleValue:		{rtn = "SMinSampleValue"; break;};
		case SMaxSampleValue:		{rtn = "SMaxSampleValue"; break;};
			
		default:break;
	}
	return rtn;
}

enum t_mlTiffCompression{
	Nocompression			= 1,
	ModifiedHuffman			= 2,
	PackBits				= 32773,
};

static inline const char* ml_getTiffCompressionStr(uint16_t compression){
	const char* rtn = "unknown";
	switch (compression) {
		case Nocompression:			{rtn = "Nocompression"; break;}
		case ModifiedHuffman:		{rtn = "ModifiedHuffman"; break;}
		case PackBits:				{rtn = "Packbits"; break;}
		default:break;
	}
	return rtn;
}

enum t_mlTiffPhotometricInterpretation{
	whiteIsZero				= 0,
	blackisZero				= 1,
};

static inline const char* ml_getTiffPhotometricInterpretationStr(uint16_t photometricInterpretation){
	const char* rtn = "unknown";
	switch (photometricInterpretation) {
		case whiteIsZero:		{rtn = "WhiteIsZero"; break;}
		case blackisZero:		{rtn = "BlackIsZero"; break;}
		default:break;
	}
	return rtn;
}


struct t_mlTiffHeader{
	uint16_t	byte_order;		// 0x4949 : little endian, 0x4D4D : big endian
	uint16_t	magic;			// 42
	uint32_t	first_ifd_offset;// ** need to keep the content (palette)
	t_mlTiffHeader():magic(0),byte_order(0),first_ifd_offset(0){};
	void print(){
		printf("- Tiff header (%ld bytes) -\n",sizeof(t_mlTiffHeader));
		printf("\tbyte ofset       = 0x%04X\n", byte_order);
		printf("\tmagic            = %d\n",magic);
		printf("\tifd offset       = %d\n",first_ifd_offset);
	}
} __attribute__((packed));

struct t_mlTiffInfo{
	uint32_t	imgWidth;
	uint32_t	imgHeight;
	uint8_t		imgWidthBytes;
	uint8_t		imgHeightBytes;
	uint16_t	bitsPerSample;
	uint16_t	compression;
	uint16_t	orientation;
	uint16_t	photometricInterpretation;
	std::string	make;
	std::string software;
	std::string dateTime;
	std::vector<uint32_t>	stripOffsets;
	uint16_t	samplesPerPixel;
	uint16_t	rowsPerStrip;
	uint16_t	planarConfiguration;
	uint16_t	sampleFormat;
	std::vector<uint32_t>	stripByteCounts;
	t_mlTiffInfo(){};
	void print(){
		printf("- Tiff Image Info -\n");
		printf("\twidth                    = %d\n", imgWidth);
		printf("\theight                   = %d\n", imgHeight);
		printf("\tbitsPerSample            = %d\n", bitsPerSample);
		printf("\tcompression              = %d [%s]\n", compression,
			   ml_getTiffCompressionStr(compression));
		printf("\tPhotometricInterpretation= %d [%s]\n", photometricInterpretation,
			   ml_getTiffPhotometricInterpretationStr(photometricInterpretation));
		printf("\tsamplesPerPixel          = %d\n", samplesPerPixel);
		printf("\trowsPerStrip             = %d\n", rowsPerStrip);
		printf("\tplanarConfiguration      = %d\n", planarConfiguration);
		if (make.size())
			printf("\tMake                     = %s\n", make.c_str());
		if (software.size())
			printf("\tSoftware                 = %s\n", software.c_str());
		if (dateTime.size())
			printf("\tDatetime                 = %s\n", dateTime.c_str());
	}
} __attribute__((packed));

enum t_mlTiffType{
	kTiff_BYTE		= 1,
	kTiff_ASCII		= 2,
	kTiff_SHORT		= 3,
	kTiff_LONG		= 4,
	kTiff_RATIONAL	= 5,
	kTiff_SBYTE		= 6,
	kTiff_UNDEFINED = 7,
	kTiff_SSHORT	= 8,
	kTiff_SLONG		= 9,
	kTiff_SRATIONAL = 10,
	kTiff_FLOAT		= 11,
	kTiff_DOUBLE	= 12,
};

static inline const char* ml_getTiffFdFieldTypeStr(uint8_t field_type){
	const char* rtn = "unknown";
	if (field_type==kTiff_BYTE)				rtn = "BYTE";	// uint8_t
	else if (field_type==kTiff_ASCII)		rtn = "ASCII";	// 7bit ASCII + NULL
	else if (field_type==kTiff_SHORT)		rtn = "SHORT";	// uint16_t
	else if (field_type==kTiff_LONG)		rtn = "LONG";	// uint32_t
	else if (field_type==kTiff_RATIONAL)	rtn = "RATIONAL";	// uint32_t / uint32_t
	else if (field_type==kTiff_SBYTE)		rtn = "SBYTE";	// int8_t
	else if (field_type==kTiff_UNDEFINED)	rtn = "UNDEFINED"; // 8bit anything
	else if (field_type==kTiff_SSHORT)		rtn = "SSHORT";	// int16_t
	else if (field_type==kTiff_SLONG)		rtn = "SLONG";	// int32_t
	else if (field_type==kTiff_SRATIONAL)	rtn = "SRATIONAL"; // int32_t / int32_t
	else if (field_type==kTiff_FLOAT)		rtn = "FLOAT";	// float
	else if (field_type==kTiff_DOUBLE)		rtn = "DOUBLE";	// double
	return rtn;
}

static inline const uint8_t ml_getTiffFdFieldTypeBytes(uint8_t field_type){
	uint8_t rtn = 0;
	if (field_type==kTiff_BYTE)			rtn = 1; //"BYTE";	// uint8_t
	else if (field_type==kTiff_SHORT)	rtn = 2; //"SHORT";	// uint16_t
	else if (field_type==kTiff_LONG)	rtn = 4; //"LONG";	// uint32_t
	else if (field_type==kTiff_SBYTE)	rtn = 1; //"SBYTE";	// int8_t
	else if (field_type==kTiff_SSHORT)	rtn = 2; //"SSHORT";// int16_t
	else if (field_type==kTiff_SLONG)	rtn = 4; //"SLONG";	// int32_t
	else if (field_type==kTiff_FLOAT)	rtn = sizeof(float);//"FLOAT";	// float
	else if (field_type==kTiff_DOUBLE)	rtn = sizeof(double); //"DOUBLE";	// double
	return rtn;
}

enum t_mlTiffSampleFormat{
	kTiff_sfUnsignedInt		= 1,
	kTiff_sfSignedInt		= 2,
	kTiff_sfFloat			= 3,
	kTiff_sfUndefined		= 4,
};

static inline const char* ml_getTiffFdSampleFormatStr(uint16_t sampleFormat){
	const char* rtn = "unknown";
	if (sampleFormat==kTiff_sfUnsignedInt)	rtn = "Unsigned Integer Data";	// uint8_t
	else if (sampleFormat==kTiff_sfSignedInt)	rtn = "Two's complement Signed Integer Data";	// uint16_t
	else if (sampleFormat==kTiff_sfFloat)		rtn = "IEEE Floating";	// uint32_t
	else if (sampleFormat==kTiff_sfUndefined)	rtn = "Undefined Data Format";	// int8_t
	return rtn;
}

struct t_mlTiffIFD{
	uint16_t	tag;
	uint16_t	field_type;
	uint32_t	type_cnt;
	uint32_t	value_offset;
	t_mlTiffIFD():tag(0),field_type(0),type_cnt(0),value_offset(0){};
	void print(){
		printf("\ttag           = %d [%s]\n", tag, ml_getTiffFdTagStr(tag));
		printf("\ttype          = %d [%s]\n", field_type, ml_getTiffFdFieldTypeStr(field_type));
		printf("\ttype count    = %d\n", type_cnt);
		printf("\tvalue offset  = %d\n", value_offset);
	}
} __attribute__((packed));
check_compile_time(sizeof(t_mlTiffIFD) == 12);

#define TIFF_LITTLE_ENDIAN	0x4949
#define TIFF_BIG_ENDIAN		0x4D4D

class CML_tiff{
	std::vector<uint8_t>	_raw_data;
private:
	t_mlError decodeIFD(FILE* fp, t_mlTiffIFD* pIfd);
public:
	t_mlTiffHeader*				pTiff_hdr;
	t_mlTiffInfo				tiff_info;
	std::vector<uint8_t>		img_data;
public:
	CML_tiff():_raw_data(NULL), pTiff_hdr(NULL), img_data(NULL){};
	CML_tiff(std::string fn);
	~CML_tiff(){};
	/* basic functions
	 */
	t_mlError load(std::string fn);	// load tiff file
	bool isValid(){return pTiff_hdr!=NULL && img_data.size()!=0;};
	/* utils / debug tools
	 */
	void saveAsCsv(std::string fn);
};

#endif//#if defined(__cplusplus)
#endif//#if !TARGET_OS_IPHONE

#endif//ifndef _ML_IMAGE_H_
