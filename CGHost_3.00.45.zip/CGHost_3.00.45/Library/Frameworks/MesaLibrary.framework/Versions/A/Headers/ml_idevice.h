//
//  ml_idevice.h
//
//  Created by Joon Kwon on 2/23/15.
//  Copyright (c) 2015 APPLE. All rights reserved.
//

#ifndef _ML_I_DEVICE_DETECTOR_H_
#define _ML_I_DEVICE_DETECTOR_H_
#include "ml_typedef.h"
#if !TARGET_OS_IPHONE
#include <MobileDevice/MobileDevice.h>
#include <MobileDevice/AMDServiceConnection.h>

#define kML_lockdownService_grape	"com.apple.grapecal"
#define kML_lockdownService_mesa	"com.apple.mesacal"

/***************************************************************************************************
 *	CML_iDeviceDetector
 *	Description:	wait for iDevice to be connected and send notification
 */
#pragma mark -
#pragma mark CML_iDeviceDetector

#if defined(__cplusplus)
/*	iDevice detector callback interface
 */
struct IML_iDeviceDetectorCallback {
	virtual void	onIDeviceAttached	(const char* serviceName, uint32_t locationId, int skt) = 0;
};

/*	CML_iDeviceDetector
 */
class CML_iDeviceDetector: public CML_baseObject {
protected:
	const char* _svcName;
	AMDeviceNotificationRef _notiRef;
	AMDeviceRef _devRef;
	AMDServiceConnectionRef	_connRef;
	uint32_t _locationId;
	// callback
	IML_iDeviceDetectorCallback* _callBack;
public:
	CML_iDeviceDetector();
	CML_iDeviceDetector(CML_logManager* lm);
	virtual ~CML_iDeviceDetector();
	t_mlError setLogManager(CML_logManager* lm);
public:
	t_mlError launch(const char* svcName, IML_iDeviceDetectorCallback* callback);
	//		description
	//			launches iDeviceDetector and wait for the iDevice where svcName is available.
	//		parameter:
	//			svcName		- the name of the service available via Lockdown Service
	//			callback	- callback interface pointer (IML_iDeviceDetectorCallback)
	//		return
	//			t_mlError	- MesaLibrary error code
	t_mlError create(const char* svcName,  IML_iDeviceDetectorCallback* callback);
	//		description
	//			detect the device connected and create service and socket
	//			this method should be only used for the device always connected.
	//			for dynamic device detection, please use launch
	//		parameter:
	//			svcName		- the name of the service available via Lockdown Service
	//			callback	- callback interface pointer (IML_iDeviceDetectorCallback)
	//		return
	//			t_mlError	- MesaLibrary error code
	t_mlError lds(AMDeviceNotificationInfo *info);
};
#endif//if !TARGET_OS_IPHONE
#endif//defined(__cplusplus)
#endif//ifndef _ML_I_DEVICE_DETECTOR_H_
